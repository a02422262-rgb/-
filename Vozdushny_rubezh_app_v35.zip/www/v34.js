/* ===== v34: настоящий радар (режимы/захват/сброс/пуск), классы ракет, новые ракеты, голосовой информатор («Рита» и др.) ===== */
(function(){
'use strict';
if(typeof WC==='undefined'||typeof PL==='undefined'||typeof radar!=='function'){console.warn('[v34] игра не готова');return}
/* ---------- 1. КЛАССЫ РАКЕТ ---------- */
function wcls(w,id){if(!w||w.t!='m')return'';const r=w.rng;if(id&&/^sam\d?$/.test(id))return'ЗУР наземного ПВО · полуактивная РЛС';if(id=='stinger'||id=='igla'||id=='hmis')return'ИК · ПЗРК';if(id=='harpoon')return'Противокорабельная';
 if(w.kind=='ir')return r<=3000?'ИК · ближнего боя (SRAAM)':'ИК · средней дальности';
 if(w.kind=='sarh')return r<=4500?'ПАРЛС · средней дальности (MRAAM)':'ПАРЛС · дальнего боя (LRAAM)';
 if(w.kind=='arh')return r<=7000?'АРЛС · средней дальности (MRAAM)':'АРЛС · дальнего боя (LRAAM)';
 if(w.kind=='arm')return'ПРР · пассивная, наводится на излучение РЛС';
 if(w.kind=='atgm')return'ТВ/ИК/лазерная · по наземным целям и кораблям';
 if(w.kind=='pd')return'Противоракета';return''}
const CLS_SHORT={ir:'ИК',sarh:'ПАРЛС',arh:'АРЛС',arm:'ПРР',atgm:'ПТУР/УР',pd:'ПРО'};
window.wcls=wcls;
/* ---------- 2. НОВЫЕ РАКЕТЫ ---------- */
const NEW={
 irist:IR('IRIS-T','IRIS-T',1050,4.7,1.5,2800,58),
 mica_ir:IR('MICA IR','MICA IR',1100,3.9,1.3,4200,62),
 mica_em:RD('MICA EM','MICA EM','arh',1150,3.1,5400,72),
 r27t:IR('Р-27Т (ИК)','Р-27Т',1050,2.5,1.05,4600,72),
 r27er:RD('Р-27ЭР','Р-27ЭР','sarh',1150,2.4,7000,82),
 r33:RD('Р-33','Р-33','sarh',1450,2,9500,98),
 aim54:RD('AIM-54C Phoenix','AIM-54','arh',1500,2.1,12500,100),
 kh25mp:{n:'Х-25МП (ПРР)',s:'Х-25МП',t:'m',kind:'arm',sp:900,tr:2,life:9,burn:4,gim:1.2,rng:6000,dmg:85,q:1},
 kh31p:{n:'Х-31П (ПРР)',s:'Х-31П',t:'m',kind:'arm',sp:1100,tr:2.1,life:9,burn:4,gim:1.2,rng:7500,dmg:90,q:1},
 agm65:{n:'AGM-65 Maverick',s:'Maverick',t:'m',kind:'atgm',sp:760,tr:2.4,life:8,burn:3,gim:1,rng:5200,dmg:85,q:2},
 kh29:{n:'Х-29Т',s:'Х-29',t:'m',kind:'atgm',sp:900,tr:2.2,life:8,burn:3,gim:1,rng:5800,dmg:110,q:1},
 harpoon:{n:'AGM-84 Harpoon',s:'Harpoon',t:'m',kind:'atgm',sp:650,tr:1.8,life:10,burn:5,gim:1,rng:7000,dmg:130,q:1,dsc:'противокорабельная: корабли и крупные цели'}
};
const NDSC={irist:'IRIS-T: всенаправленная ИК-ракета, большой угол ГСН',mica_ir:'MICA: ИК-вариант ракеты средней дальности',mica_em:'MICA: активная РЛС-ГСН, пустил и забыл',r27t:'Р-27: тепловая ГСН, средняя дальность',r27er:'Р-27ЭР: полуактивная РЛС, нужна подсветка до попадания',r33:'Р-33: дальняя ПАРЛС, нужна подсветка до попадания',aim54:'Феникс: сверхдальняя АРЛС, включает ГСН на последнем участке',kh25mp:'пассивная: летит на излучающую РЛС, ЗРК, корабль',kh31p:'пассивная: быстрая противорадиолокационная',agm65:'Maverick: любые наземные цели и корабли',kh29:'Х-29: бетонобойная, мосты, склады, укрепления'};
const ALIAS={irist:'aim9x',mica_ir:'aim9x',mica_em:'aim120',r27t:'r27',r27er:'r27',r33:'r37',aim54:'r37',kh25mp:'x58',kh31p:'x58',agm65:'hellfire',kh29:'x58',harpoon:'x58'};
const COST={irist:900,mica_ir:1000,mica_em:2800,r27t:900,r27er:1100,r33:3600,aim54:5200,kh25mp:3000,kh31p:3600,agm65:1800,kh29:2600,harpoon:3200};
for(const k in NEW){if(!WC[k]){WC[k]=NEW[k]}if(NDSC[k])WC[k].dsc=NDSC[k]}
try{for(const k in ALIAS){const b=ALIAS[k];if(typeof MS!=='undefined'&&!MS[k])MS[k]=MS[b]||MS.sam;if(typeof MSP!=='undefined'&&!MSP[k])MSP[k]=MSP[b]||MSP.sam}}catch(e){}
try{if(typeof WU!=='undefined')for(const k in COST)if(!WU[k])WU[k]=COST[k]}catch(e){}
/* добавляем на самолёты (по названию) */
const LOAD=[['F-14',['aim54']],['МиГ-31',['r33','r27er']],['Су-27',['r27t','r27er','kh31p']],['Су-35',['r27t','r27er','kh31p']],['Су-57',['r27er','kh31p']],['МиГ-29',['r27t','kh31p','kh29']],['МиГ-23',['r27t']],['Mirage',['mica_ir','mica_em']],['Rafale',['mica_ir','mica_em','agm88']],['Eurofighter',['irist','agm88']],['Gripen',['irist']],['Tornado',['agm88','harpoon']],['F-16',['agm65','agm88']],['F-4',['agm65','harpoon']],['F-15',['agm65']],['A-10',['agm65']],['Су-25',['kh25mp','kh29']],['Су-24',['kh25mp','kh29','kh31p']],['Су-34',['kh31p','kh29','kh25mp']],['A-6',['harpoon','agm65']],['F-111',['agm88','harpoon']],['F-22',['aim120']]];
for(const[nm,ids]of LOAD){for(const d of PL){if(d.n.indexOf(nm)<0)continue;for(const id of ids){if(!WC[id]||d.wo.includes(id))continue;const i=d.wo.indexOf('mk82');d.wo.splice(i<0?d.wo.length:i,0,id)}}}
/* описания-классы для всех ракет */
for(const k in WC){const w=WC[k];if(w.t!='m')continue;const c=wcls(w,k);w.cls=c;const km=(w.rng/1000).toFixed(1).replace('.0','');if(!w._d0){w._d0=w.dsc||''}w.dsc=c+' · '+km+' км'+(w._d0?' · '+w._d0:'')}
/* ---------- 3. РЛС ---------- */
const hasRadar=()=>!!(P&&P.d&&P.d.rad);
const AZ_ALL=[[Math.PI,'360°'],[1.047,'±60°'],[.524,'±30°'],[.175,'±10°']];
const MODES=['ОБЗОР','СОПР','БЛИЖН','СЛЕЖ'],MODE_LONG=['Обзор (RWS)','Сопровождение (TWS)','Ближний бой (ACM)','Слежение (STT)'];
const RX={on:true,mode:0,azi:1,sw:0,dir:1,stt:null,tgtL:null,lt:0,need:1,notch:0,los0:0,tks:[],msg:'',mt:0,tone:0,pm:0,_p:null,azl:[]};
window.RX=RX;
function azList(){const rf=(P.d&&P.d.rf)||360,lim=rf>=360?Math.PI:rf*Math.PI/360;let l=AZ_ALL.filter(a=>a[0]<=lim+1e-3);if(!l.length||l[0][0]<lim-1e-3&&lim<1.047)l.unshift([lim,'±'+Math.round(lim*57.3)+'°']);return l}
function rxReset(){RX._p=P;RX.on=true;RX.mode=0;RX.stt=null;RX.tgtL=null;RX.tks=[];RX.sw=0;RX.dir=1;RX.azl=azList();RX.azi=RX.azl.length>1&&RX.azl[0][0]>=Math.PI?1:0;RX.notch=0;RX.msg='';RX.fail=0}
const azEff=()=>RX.mode==2?.175:(RX.azl[RX.azi]||[1.047])[0];
const rxmsg=(t,c)=>{RX.msg=t;RX.mt=tm+2.6;RX.mc=c||'#ffb020'};
function capOf(e){const d=hyp(e.x-P.x,e.y-P.y),mr=(P.d.rg||8000)*Math.pow(e.rcs||1,.25)*(P.dm?1-.3*P.dm[3]:1)*(wx==2?.7:1);return[d,mr]}
function losC(e){const k=Math.floor(tm*2.5);if(e._rxl!==k){e._rxl=k;e._rxv=los(P,e)}return e._rxv}
const bearing=e=>wr(Math.atan2(e.y-P.y,e.x-P.x)-P.a);
function airTargets(){const L=[];for(const e of E)if(!e.dead)L.push(e);for(const g of G)if(g.air&&!g.dead)L.push(g);return L}
/* видимость: радар (луч/память) + визуально + земля как раньше */
const rvis0=window.rvis||rvis;
rvis=function(e){if(!P||P.dead)return false;if(!hasRadar()||e.g&&!e.air||(e.ty&&!e.air))return rvis0(e);
 const d=hyp(e.x-P.x,e.y-P.y);if(d<1800){e.sn=tm;return true}
 if(wx==2&&RJ>0&&d>900)return false;if(JAM&&d>2600&&!e.jm&&!(P.ecm&&d<5200))return false;
 const mem=RX.stt===e?.3:(RX.mode==1?3.4:2.3);return RX.on&&tm-(e.sn||-9)<mem};
function paintAll(dt,prev){const az=azEff(),bw=.1,lo=Math.min(prev,RX.sw)-bw,hi=Math.max(prev,RX.sw)+bw;
 for(const e of airTargets()){const[d,mr]=capOf(e);if(d>=mr||d<1800)continue;const a=bearing(e);if(Math.abs(a)>az+.02)continue;
  const inb=RX.stt?(e===RX.stt):(a>=lo&&a<=hi);if(!inb)continue;if(!losC(e))continue;e.sn=tm;
  if(RX.mode==1&&RX.tks.length<4&&!RX.tks.includes(e))RX.tks.push(e)}}
function rxBreak(why){if(RX.stt){rxmsg('ЗАХВАТ ПОТЕРЯН: '+why,'#ff6a5a');toast('Захват потерян: '+why)}RX.stt=null;RX.tgtL=null;RX.mode=RX.pm<3?RX.pm:0;RX.notch=0;P.lock=null}
function startLock(t){if(!t)return;RX.tgtL=t;RX.lt=0;const[d,mr]=capOf(t);RX.need=.8+1.3*d/mr+(JAM?1:0)+(t.jm?1.4:0);rxmsg('ЗАХВАТ…','#ffd24a')}
function bestTarget(){let b=null,bd=9;for(const e of airTargets()){if(!rvis(e))continue;const[d,mr]=capOf(e);if(d>=mr)continue;const a=Math.abs(bearing(e));if(a>azEff())continue;if(a<bd){bd=a;b=e}}return b}
function rxPress(id){
 if(id=='on'){if(!hasRadar()){toast('На этом самолёте нет бортового радара');return}RX.on=!RX.on;if(!RX.on){RX.stt=null;RX.tgtL=null;RX.tks=[];P.lock=null}toast(RX.on?'РЛС включена':'РЛС выключена (радиомолчание)');return}
 if(!hasRadar()){toast('Бортового радара нет: цели с земли');return}
 if(id=='mode'){RX.stt=null;RX.tgtL=null;P.lock=null;RX.mode=(RX.mode>=2?0:RX.mode+1);RX.pm=RX.mode;RX.tks=[];toast('Режим РЛС: '+MODE_LONG[RX.mode]);return}
 if(id=='az'){RX.azi=(RX.azi+1)%RX.azl.length;toast('Сектор обзора '+RX.azl[RX.azi][1]);return}
 if(id=='rng'){const Z=[4000,8000,16000,24000,32000];RG=Z[(Z.indexOf(RG)+1)%Z.length];toast('Масштаб РЛС: '+RG/1000+' км');return}
 if(id=='lock'){if(!RX.on){toast('Включи РЛС');return}if(RX.stt){rxmsg('СЛЕЖЕНИЕ · цель уже захвачена','#6fe09a');return}
  let t=(P.des&&!P.des.dead&&rvis(P.des)&&(P.des.air||!P.des.ty))?P.des:bestTarget();if(!t){rxmsg('НЕТ ЦЕЛЕЙ В СЕКТОРЕ','#ff6a5a');toast('Нет целей в секторе радара');return}
  const[d,mr]=capOf(t);if(d>=mr){rxmsg('ЦЕЛЬ ВНЕ ДАЛЬНОСТИ','#ff6a5a');return}P.des=t;RX.pm=RX.mode<3?RX.mode:0;startLock(t);return}
 if(id=='rel'){if(RX.stt||RX.tgtL||P.lock){const had=RX.stt;RX.stt=null;RX.tgtL=null;P.lock=null;RX.mode=RX.pm<3?RX.pm:0;rxmsg(had?'ЗАХВАТ СНЯТ':'СБРОС','#9cc0de');toast('Захват снят')}else{P.des=null;toast('Цель сброшена')}return}
}
function rxUpdate(dt){if(!P||P.dead||state!='play')return;if(RX._p!==P)rxReset();if(!hasRadar()){RX.stt=null;return}
 if(P.dm&&P.dm[3]>=2){if(RX.on){RX.on=false;toast('РЛС разрушена')}RX.stt=null;RX.tgtL=null}
 const az=azEff();const prev=RX.sw;
 if(RX.on&&!RX.stt){RX.sw+=RX.dir*2.6*dt*(az>2?1.5:1);if(RX.sw>az){RX.sw=az;RX.dir=-1}if(RX.sw<-az){RX.sw=-az;RX.dir=1}}
 else if(RX.stt)RX.sw=cl(bearing(RX.stt),-1.4,1.4);
 if(RX.on)paintAll(dt,prev);
 // сопровождение: треки обновляются непрерывно
 if(RX.mode==1){RX.tks=RX.tks.filter(t=>{if(t.dead)return false;const[d,mr]=capOf(t);if(d>=mr||Math.abs(bearing(t))>az*1.1||!losC(t))return false;t.sn=tm;return true})}else if(RX.mode!=3)RX.tks=[];
 // ближний бой: автозахват по оси
 if(RX.on&&RX.mode==2&&!RX.stt&&!RX.tgtL){let b=null,bd=9;for(const e of airTargets()){const[d,mr]=capOf(e);if(d>=Math.min(mr,9000)||!losC(e))continue;const a=Math.abs(bearing(e));if(a<.175&&a<bd){bd=a;b=e}}if(b){P.des=b;startLock(b)}}
 // процесс захвата
 if(RX.tgtL){const t=RX.tgtL,[d,mr]=capOf(t),a=Math.abs(bearing(t));
  if(t.dead||!RX.on||d>=mr||a>(RX.mode==2?.35:az+.1)||!losC(t)){RX.tgtL=null;rxmsg('ЗАХВАТ НЕ УДАЛСЯ','#ff6a5a')}
  else{RX.lt+=dt;t.sn=tm;if(RX.lt>=RX.need){RX.stt=t;RX.tgtL=null;P.des=t;RX.mode=3;RX.notch=0;rxmsg('СЛЕЖЕНИЕ · '+rnm(t),'#6fe09a');toast('Захват цели: '+rnm(t));snd(1700,.12,'square',.04);setTimeout(()=>snd(1700,.12,'square',.04),160)}}}
 // слежение: условия срыва
 if(RX.stt){const t=RX.stt,[d,mr]=capOf(t),a=Math.abs(bearing(t));
  if(t.dead||!RX.on){rxBreak(t.dead?'цель уничтожена':'РЛС выключена')}
  else if(a>1.22)rxBreak('цель вышла за пределы антенны')
  else if(d>mr*1.15)rxBreak('цель за пределами дальности')
  else if(JAM&&d>2600&&!t.jm&&!(P.ecm&&d<5200))rxBreak('помехи')
  else{t.sn=tm;if(!losC(t)){RX.los0+=dt;if(RX.los0>1.5)rxBreak('потеря прямой видимости')}else RX.los0=0;
   const ux=(t.x-P.x)/(d||1),uy=(t.y-P.y)/(d||1),vx=Math.cos(t.a||0)*(t.v||0)-Math.cos(P.a)*P.v,vy=Math.sin(t.a||0)*(t.v||0)-Math.sin(P.a)*P.v;RX.vc=-(vx*ux+vy*uy);
   if(Math.abs(RX.vc)<45&&d>1800){RX.notch+=dt;if(RX.notch>1.6)rxBreak('доплеровский провал (цель на траверзе)')}else RX.notch=Math.max(0,RX.notch-dt*2)}}
 // подсветка для ПАРЛС и АРЛС до активации ГСН
 for(const m of M){if(m.own!==P||!m.tg||m.age<.5)continue;const w=WC[m.id];if(!w)continue;
  if(w.kind=='sarh'&&!(RX.stt===m.tg&&RX.on)){m.tg=null;toast('Подсветка потеряна: ПАРЛС-ракета ушла в сторону')}
  else if(w.kind=='arh'&&!m.pit){const dd=hyp(m.x-m.tg.x,m.y-m.tg.y);if(dd<w.rng*.38){m.pit=1;toast('ГСН ракеты включена: пустил и забыл')}else if(!(RX.stt===m.tg||RX.tks.includes(m.tg)||(P.des===m.tg&&RX.on))){m._ng=(m._ng||0)+dt;if(m._ng>1.6){m.tg=null;toast('Нет сопровождения: АРЛС-ракета потеряла цель')}}else m._ng=0}}
 // тоны захвата
 RX.tone-=dt;const w=WC[ws];if(P.lock&&w&&w.t=='m'&&RX.tone<=0){if(w.kind=='ir'){snd(980+Math.sin(tm*3)*40,.16,'sine',.03);RX.tone=.22}else if(w.kind=='sarh'||w.kind=='arh'){snd(1900,.05,'square',.012);RX.tone=.5}else if(w.kind=='arm'){snd(700,.1,'triangle',.03);RX.tone=.35}}
}
/* захват оружия */
const doLock0=doLock;
doLock=function(){const w=WC[ws];
 if(w&&w.t=='m'&&(w.kind=='sarh'||w.kind=='arh')){P.lock=null;if(!hasRadar()||!RX.on||P.dead)return;let t=null;
  if(RX.stt&&!RX.stt.dead)t=RX.stt;else if(w.kind=='arh'&&RX.mode==1&&P.des&&RX.tks.includes(P.des)&&!P.des.dead)t=P.des;
  if(t){const d=hyp(t.x-P.x,t.y-P.y);if(d<w.rng*P.lr*dr(t,w))P.lock=t}return}
 doLock0();
 if(w&&w.t=='m'&&w.kind=='arm'&&!P.lock){const cone=1.1;let bd=cone;for(const g of G){if(g.dead||!g.g||(g.ty!='radar'&&g.ty!='sam'&&g.ty!='ship'&&g.ty!='aaa'))continue;const d=hyp(g.x-P.x,g.y-P.y);if(d>w.rng*P.lr)continue;const a=Math.abs(bearing(g));if(a<bd){bd=a;P.lock=g}}}};
/* ---------- 4. ОТРИСОВКА РАДАРА ---------- */
let RXB=[];
const rxb=(x,y,w,h,id,l,on,en,l2)=>{RXB.push({x,y,w,h,id,en});X.fillStyle=on?'rgba(255,176,32,.95)':en?'rgba(38,70,98,.92)':'rgba(40,46,52,.8)';X.fillRect(x,y,w,h);X.strokeStyle='rgba(140,190,210,.4)';X.lineWidth=1;X.strokeRect(x+.5,y+.5,w-1,h-1);X.textAlign='center';X.fillStyle=on?'#1b1204':en?'#cfe6f5':'#6f7b84';
 if(l2){X.font='700 8px Bahnschrift,"Arial Narrow",sans-serif';X.fillText(l,x+w/2,y+9);X.font='800 11px Bahnschrift,"Arial Narrow",sans-serif';X.fillText(l2,x+w/2,y+h-3)}else{X.font='800 11px Bahnschrift,"Arial Narrow",sans-serif';X.fillText(l,x+w/2,y+h/2+4)}};
radar=function(){if(!P||P.dead)return;if(RX._p!==P)rxReset();
 const[rx,ry]=rxy(),s=RR/RG,cs=Math.cos(P.a),sn=Math.sin(P.a),w=WC[ws],rk=w&&w.t=='m'&&(w.kind=='sarh'||w.kind=='arh'||w.kind=='arm'),F9='700 9px Bahnschrift,"Arial Narrow",sans-serif',has=hasRadar(),az=azEff();
 RXB=[];X.save();X.fillStyle='rgba(6,10,12,.92)';X.beginPath();X.arc(rx,ry,RR+10,0,6.3);X.fill();
 let g=X.createLinearGradient(rx-RR,ry-RR,rx+RR,ry+RR);g.addColorStop(0,'rgba(190,210,225,.55)');g.addColorStop(.5,'rgba(70,90,105,.35)');g.addColorStop(1,'rgba(190,210,225,.5)');X.strokeStyle=g;X.lineWidth=2.4;X.beginPath();X.arc(rx,ry,RR+8.5,0,6.3);X.stroke();
 for(let i=0;i<36;i++){const a=i*.17453,l=i%3?3:6;X.strokeStyle=i%9?'rgba(160,200,220,.4)':'rgba(255,255,255,.8)';X.lineWidth=i%9?1:1.6;X.beginPath();X.moveTo(rx+Math.sin(a)*(RR+1),ry-Math.cos(a)*(RR+1));X.lineTo(rx+Math.sin(a)*(RR+1+l),ry-Math.cos(a)*(RR+1+l));X.stroke()}
 g=X.createRadialGradient(rx,ry,0,rx,ry,RR);g.addColorStop(0,'#0d3322');g.addColorStop(.7,'#08241a');g.addColorStop(1,'#041510');X.fillStyle=g;X.beginPath();X.arc(rx,ry,RR,0,6.3);X.fill();
 X.save();X.beginPath();X.arc(rx,ry,RR,0,6.3);X.clip();
 if(has){const on=RX.on;if(az<3){X.fillStyle=on?'rgba(120,255,170,.11)':'rgba(120,120,120,.08)';X.beginPath();X.moveTo(rx,ry);X.arc(rx,ry,RR,-1.5708-az,-1.5708+az);X.closePath();X.fill();X.strokeStyle='rgba(120,255,170,.55)';X.lineWidth=1;X.beginPath();X.moveTo(rx,ry);X.lineTo(rx-Math.sin(az)*RR,ry-Math.cos(az)*RR);X.moveTo(rx,ry);X.lineTo(rx+Math.sin(az)*RR,ry-Math.cos(az)*RR);X.stroke()}}
 X.strokeStyle='rgba(110,255,170,.28)';X.lineWidth=1;[.25,.5,.75,1].forEach(k=>{X.beginPath();X.arc(rx,ry,RR*k,0,6.3);X.stroke()});X.beginPath();X.moveTo(rx-RR,ry);X.lineTo(rx+RR,ry);X.moveTo(rx,ry-RR);X.lineTo(rx,ry+RR);X.stroke();
 if(has&&RX.on){const a0=RX.sw;for(let k=0;k<14;k++){const a1=a0-RX.dir*k*.05;X.fillStyle='rgba(90,255,160,'+(.3*(1-k/14)*(1-k/14))+')';X.beginPath();X.moveTo(rx,ry);X.arc(rx,ry,RR,-1.5708+a1-.045,-1.5708+a1+.045);X.closePath();X.fill()}
  X.strokeStyle=RX.stt?'rgba(255,255,255,.9)':'rgba(170,255,200,.85)';X.lineWidth=RX.stt?1.8:1.3;X.beginPath();X.moveTo(rx,ry);X.lineTo(rx+Math.sin(RX.sw)*RR,ry-Math.cos(RX.sw)*RR);X.stroke()}
 X.fillStyle='rgba(120,255,170,.65)';X.font=F9;X.textAlign='center';[.25,.5,.75,1].forEach(k=>X.fillText((RG/1000*k|0)+'',rx+3,ry-RR*k+9));
 const pt=e=>{const dx=e.x-P.x,dy=e.y-P.y;return[rx+(-dx*sn+dy*cs)*s,ry-(dx*cs+dy*sn)*s]};
 const age=e=>{const mem=RX.mode==1?3.4:2.3;return cl(1-(tm-(e.sn||-9))/(mem*1.05),.3,1)};
 const alm=(e,x,y,c)=>{const d=AL(e)-P.al;if(Math.abs(d)>.15){X.fillStyle=c;X.font='800 8px Bahnschrift,sans-serif';X.textAlign='left';X.fillText(d>0?'▲':'▼',x+6,y+3)}};
 M.forEach(m=>{const[x,y]=pt(m);if(hyp(x-rx,y-ry)<RR-3){X.globalAlpha=1;const pdm=WC[m.id]&&WC[m.id].kind=='pd';X.fillStyle=pdm?'#4de8ff':m.tg===P?'#ff3b3b':m.team?'#ff9a5a':'#9dffb5';X.fillRect(x-1.5,y-1.5,3,3);if(pdm&&m.tg&&m.tg.life!==undefined){const[tx,ty]=pt(m.tg);X.strokeStyle='rgba(77,232,255,.6)';X.lineWidth=1;X.beginPath();X.moveTo(x,y);X.lineTo(tx,ty);X.stroke()}}});
 const mark=(e,x,y)=>{const trk=RX.tks.includes(e);if(P.des===e||RX.stt===e||trk){const st=RX.stt===e,c=st?'#fff':P.des===e?'#ffd24a':'#9cd0ff',q=st?11:10;X.globalAlpha=1;X.strokeStyle=c;X.lineWidth=st?2:1.5;X.beginPath();if(st||trk&&P.des!==e){X.rect(x-q+3,y-q+3,2*q-6,2*q-6)}else for(const[sx,sy]of[[1,1],[1,-1],[-1,1],[-1,-1]]){X.moveTo(x+sx*q,y+sy*(q-4));X.lineTo(x+sx*q,y+sy*q);X.lineTo(x+sx*(q-4),y+sy*q)}X.stroke();
  if(trk||st){const vx=Math.cos(e.a||0)*(e.v||0)*s*2.5,vy=Math.sin(e.a||0)*(e.v||0)*s*2.5;X.strokeStyle='rgba(255,255,255,.6)';X.beginPath();X.moveTo(x,y);X.lineTo(x+(-vx*sn+vy*cs),y-(vx*cs+vy*sn));X.stroke()}
  if(P.des===e){X.setLineDash([2,3]);X.strokeStyle='rgba(255,255,255,.35)';X.beginPath();X.moveTo(rx,ry);X.lineTo(x,y);X.stroke();X.setLineDash([])}}},R='#ff4d4d';
 G.forEach(e=>{if(e.dead)return;const[x,y]=pt(e);if(hyp(x-rx,y-ry)>RR-3)return;
  if(e.air){if(!rvis(e))return;X.globalAlpha=age(e);ico2('heli',x,y,R,0);alm(e,x,y,R)}
  else if(e.ty=='ship'){X.globalAlpha=.8;X.save();X.translate(x,y);X.rotate(e.a-P.a-1.5708);X.fillStyle=R;X.beginPath();X.ellipse(0,0,2.2,6.5,0,0,6.3);X.fill();X.restore()}
  else{X.globalAlpha=.75;X.fillStyle=R;if(e.ty=='sam'||e.ty=='radar'||e.ty=='aaa'||e.ty=='mpad'){X.save();X.translate(x,y);X.rotate(.785);X.fillRect(-2.6,-2.6,5.2,5.2);X.restore();if(e.ty=='sam'||e.ty=='radar'){X.strokeStyle='rgba(255,77,77,.5)';X.lineWidth=1;X.beginPath();X.arc(x,y,5.5,0,6.3);X.stroke()}}else if(e.ty=='jet'||e.ty=='phel'){X.fillRect(x-2.5,y-1,5,2);X.fillRect(x-1,y-2.5,2,5)}else{const q=e.ty=='depot'||e.ty=='fuel'?3.2:2;X.fillRect(x-q,y-q,q*2,q*2)}}
  mark(e,x,y)});
 E.forEach(e=>{if(e.dead||!rvis(e))return;const[x,y]=pt(e);if(hyp(x-rx,y-ry)>RR-3)return;X.globalAlpha=age(e);ico2('air',x,y,R,e.a-P.a-1.5708);alm(e,x,y,R);X.globalAlpha=1;mark(e,x,y)});
 X.globalAlpha=1;A.forEach(a=>{if(a.dead)return;const[x,y]=pt(a);if(hyp(x-rx,y-ry)<RR-3)ico2('air',x,y,a.esc?'#5fd3ff':'#4cff7a',a.a-P.a-1.5708,a.esc?1.25:1)});
 if(AF){const[x,y]=pt(AF);if(hyp(x-rx,y-ry)<RR-3)ico2('af',x,y,'#4cff7a',0)}ico2('air',rx,ry,'#fff',-1.5708);X.restore();
 // подписи на корпусе
 X.fillStyle='rgba(120,255,170,.8)';X.font='800 8px Bahnschrift,sans-serif';X.textAlign='center';
 X.fillText(has?('РЛС · '+MODES[RX.mode]+' · '+(RX.mode==2?'±10°':RX.azl[RX.azi]?RX.azl[RX.azi][1]:'')):'НАВЕДЕНИЕ С ЗЕМЛИ',rx,ry-RR-12);
 if(has&&!RX.on){X.fillStyle='rgba(255,106,90,.95)';X.font='800 11px Bahnschrift,sans-serif';X.fillText('РЛС ВЫКЛ',rx,ry+4)}
 // левая колонка кнопок радара
 {const bx=rx-RR-74,bw=66,bh=22,gp=3;let by=ry-RR;const e1=has;
  rxb(bx,by,bw,bh,'on','РЛС',RX.on&&has,e1,has?(RX.on?'ВКЛ':'ВЫКЛ'):'НЕТ');by+=bh+gp;
  rxb(bx,by,bw,bh,'mode','РЕЖИМ',false,e1,RX.stt?'СЛЕЖ':MODES[RX.mode]);by+=bh+gp;
  rxb(bx,by,bw,bh,'az','СЕКТОР',false,e1,has?(RX.mode==2?'±10°':RX.azl[RX.azi]?RX.azl[RX.azi][1]:''):'—');by+=bh+gp;
  rxb(bx,by,bw,bh,'rng','ДАЛЬН.',false,true,(RG/1000)+' км');by+=bh+gp;
  rxb(bx,by,bw,bh,'lock','ЗАХВАТ',!!RX.tgtL||!!RX.stt,e1&&RX.on,RX.tgtL?Math.round(100*RX.lt/RX.need)+'%':RX.stt?'ДЕРЖИТ':'ЗАХВАТ');by+=bh+gp;
  rxb(bx,by,bw,bh,'rel','СБРОС',false,e1||!!P.des,'СБРОС')}
 // панель цели
 const py=ry+RR+12,pw=RR*2+8,px=rx-RR-4,d=P.des&&!P.des.dead?P.des:null;
 X.fillStyle='rgba(8,14,18,.82)';X.fillRect(px,py,pw,32);X.strokeStyle='rgba(140,190,210,.35)';X.lineWidth=1;X.strokeRect(px+.5,py+.5,pw,32);
 X.textAlign='left';X.font='800 11px Bahnschrift,"Arial Narrow",sans-serif';let l1,c1='#cfe6f5',l2='',c2='#8fb2c8';
 if(d){const km=(hyp(d.x-P.x,d.y-P.y)/100|0)/10,dl=AL(d)-P.al;l1=rnm(d)+' · '+km+' км'+(Math.abs(dl)>.15?(dl>0?' ▲':' ▼'):'');
  if(RX.tgtL){l2='ЗАХВАТ… '+Math.round(100*RX.lt/RX.need)+'%';c2='#ffd24a'}
  else if(RX.stt===d){l2='СЛЕЖЕНИЕ · Vc '+Math.round(RX.vc||0)+(RX.notch>.4?' · ПРОВАЛ!':'');c2=RX.notch>.4?'#ff6a5a':'#6fe09a'}
  else if(w&&w.t=='m'){l2=P.lock===d?(rk?'ЗАХВАТ · готов к пуску':'ЦЕЛЬ ВЫБРАНА · ГСН держит'):(rk?'нужен захват РЛС (кнопка ЗАХВАТ)':'вне зоны пуска');c2=P.lock===d?'#6fe09a':'#ffb020'}else{l2='цель выбрана';c2='#ffd24a'}}
 else{l1=rk?'ЦЕЛЬ НЕ ВЫБРАНА':'Нажми на метку';c1=rk?'#ffb020':'#cfe6f5';l2=w&&w.t=='m'?(CLS_SHORT[w.kind]||'')+' · '+(wcls(w).split('·')[1]||'').trim():(rk?'коснись цели на радаре':'для захвата радаром');c2='#8fb2c8'}
 if(RX.mt>tm&&!RX.tgtL&&!RX.stt){l2=RX.msg;c2=RX.mc}
 X.fillStyle=c1;X.fillText(l1,px+8,py+13,pw-14);X.font='700 10px Bahnschrift,"Arial Narrow",sans-serif';X.fillStyle=c2;X.fillText(l2,px+8,py+25,pw-14);
 // ВЕД / АП
 RB2=RB3=null;{const ok2=!!P.des&&A.some(a=>!a.dead),bx=[[rx-RR-4,'ВЕД',ORD==5,ok2],[rx+RR-38,'АП',!!P.ap,!P.gnd]],by=ry+RR-26;X.font='800 12px Bahnschrift,"Arial Narrow",sans-serif';X.textAlign='center';bx.forEach(([x,l,on,en],k)=>{const b={x,y:by,w:42,h:26,en};if(k)RB3=b;else RB2=b;X.fillStyle=on?'rgba(255,176,32,.95)':en?'rgba(38,70,98,.92)':'rgba(40,46,52,.8)';X.fillRect(x,by,42,26);X.strokeStyle='rgba(140,190,210,.4)';X.strokeRect(x+.5,by+.5,41,25);X.fillStyle=on?'#1b1204':en?'#cfe6f5':'#6f7b84';X.fillText(l,x+21,by+17)})}
 if(wx==2||RJ>0){X.save();X.beginPath();X.arc(rx,ry,RR,0,6.3);X.clip();const tb=Math.floor(tm*3);if(wx==2){X.fillStyle='rgba(120,230,160,.15)';for(let i=0;i<26;i++){const a=hs(i,tb)*6.28,rr2=hs(tb,i+5)*RR*.95;X.beginPath();X.arc(rx+Math.cos(a)*rr2,ry+Math.sin(a)*rr2,3+hs(i,7)*7,0,6.3);X.fill()}}
  if(RJ>0){X.globalAlpha=Math.min(1,RJ*2);X.fillStyle='rgba(190,255,210,.4)';for(let i=0;i<46;i++)X.fillRect(rx-RR+Math.random()*RR*2,ry-RR+Math.random()*RR*2,10+Math.random()*34,1.6)}X.restore();X.textAlign='center';X.font='800 10px Bahnschrift,"Arial Narrow",sans-serif';X.fillStyle=RJ>0?'#ff6a5a':'#ffd24a';X.fillText(RJ>0?'ПОМЕХИ · ГРОЗА':'ГРОЗА · дальность −30%',rx,ry+RR-10)}
 // кнопка ПУСК + зона пуска (DLZ)
 RBT=null;if(w&&w.t=='m'){const en=rk?!!P.lock:(P.inv[ws]>0),by=py+36;RBT={x:px,y:by,w:pw,h:26,en};X.fillStyle=en?'rgba(255,176,32,.92)':'rgba(70,78,84,.8)';X.fillRect(px,by,pw,26);X.fillStyle=en?'#1b1204':'#97a4ad';X.font='800 12px Bahnschrift,"Arial Narrow",sans-serif';X.textAlign='center';X.fillText(rk&&!P.lock?'ПУСК · нужен захват':'ПУСК '+w.s,px+pw/2,by+13,pw-8);
  const t=P.lock||d;if(t&&(t.air||!t.ty||t.g)){const dist=hyp(t.x-P.x,t.y-P.y),rmax=w.rng*P.lr*dr(t,w),rne=rmax*.55,rmin=500,sc=(pw-10)/(rmax*1.15),x0=px+5,yb=by+19;X.fillStyle='rgba(0,0,0,.35)';X.fillRect(x0,yb,pw-10,4);X.fillStyle='rgba(255,140,40,.9)';X.fillRect(x0+rmin*sc,yb,(rne-rmin)*sc,4);X.fillStyle='rgba(60,220,120,.95)';X.fillRect(x0+rne*sc,yb,(rmax-rne)*sc,4);const cx=x0+Math.min(dist,rmax*1.15)*sc;X.fillStyle=dist>rmax?'#ff4d4d':'#fff';X.beginPath();X.moveTo(cx,yb-1);X.lineTo(cx-3,yb-5);X.lineTo(cx+3,yb-5);X.fill()}}
 X.restore()};
/* нажатия */
const radarTap0=radarTap;
radarTap=function(e){const r=C.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;for(const b of RXB)if(x>=b.x&&x<=b.x+b.w&&y>=b.y&&y<=b.y+b.h){rxPress(b.id);return true}return radarTap0(e)};
document.addEventListener('keydown',e=>{if(state!='play'||paused)return;if(e.code=='KeyT'){rxPress('lock');e.preventDefault()}else if(e.code=='KeyU'){rxPress('rel')}else if(e.code=='KeyM'&&e.shiftKey){rxPress('mode')}});
const upd0=upd;
upd=function(dt){upd0(dt);try{rxUpdate(dt);ritaMon(dt)}catch(err){console.error('[v34]',err)}};
/* ---------- 5. ГОЛОСОВОЙ ИНФОРМАТОР (СПО): «Рита» и др. ---------- */
const VP={man:null};
try{fetch('sounds/manifest.json').then(r=>r.ok?r.json():null).then(j=>VP.man=j).catch(()=>{})}catch(e){}
function vplay(pack,key){const f=VP.man&&VP.man[pack]&&VP.man[pack][key];if(!f||MD.voice===0||MD.snd===0)return false;try{const a=new Audio('sounds/'+f);a.volume=.9;a.play().catch(()=>{});return true}catch(e){return false}}
const dirRu=b=>{const a=Math.abs(b),sd=b>=0?'справа':'слева';return a<.4?'спереди':a>2.75?'сзади':a<1.2?sd+' спереди':a>1.95?sd+' сзади':sd};
const dirFr=b=>CLK.fr[((Math.round(b/.5236)%12)+12)%12];
function voiceSay(pack,key,text,lang){RDO={t:text,t0:tm,until:tm+3.2};if(!vplay(pack,key))say(text,lang,true)}
rwSay=function(b,k){const nat=P.d.nat,key={r:'irrad',l:'lock',x:'launch',m:'missile'}[k];
 if(nat=='su'){const c=dirRu(b);voiceSay('rita',key,'СПО «Рита»: '+(k=='r'?'Внимание! Облучение. '+c:k=='l'?'Опасность! Захват. '+c+'!':k=='x'?'Опасность! Пуск ракеты. '+c+'!':'Ракета! Ракета! '+c+'. Ловушки!'),'ru')}
 else if(nat=='fr'){const c=dirFr(b);voiceSay('fr',key,'DDM: '+(k=='r'?'Radar, '+c:k=='l'?'Accrochage, '+c+' !':k=='x'?'Départ missile, '+c+' !':'Alerte missile, '+c+'. Leurres !'),'fr')}
 else{const c=CLK.en[((Math.round(b/.5236)%12)+12)%12];voiceSay('betty',key,'RWR: '+(k=='r'?'Radar, '+c:k=='l'?'Lock, lock! '+c:k=='x'?'Missile launch! '+c:'Missile, missile! '+c+'. Break! Flares!'),'en')}};
const RM={fu:100,gw:0,gt:0,bg:0};
function ritaMon(dt){if(!P||P.dead||state!='play')return;const ru=P.d.nat=='su',pack=ru?'rita':'betty',lg=ru?'ru':'en',say2=(key,tr,te)=>{if(!vplay(pack,key))say(ru?tr:te,lg,true)};
 if(RM.fu>25&&P.fu<=25&&P.fu>0){say2('fuel','Остаток топлива двадцать пять процентов','Fuel low');toast(ru?'Рита: остаток топлива 25%':'Fuel low')}
 if(RM.fu>10&&P.fu<=10&&P.fu>0){say2('fuel_crit','Критический остаток топлива!','Bingo fuel, bingo fuel')}
 RM.fu=P.fu;
 if(P.gwn&&!RM.gw){say2('alt','Опасная высота! Набери высоту!','Pull up, pull up!')}RM.gw=P.gwn?1:0;
 RM.gt-=dt;if(!P.gnd&&!P.hel&&P.grt==0&&AF&&AF.hp>0&&hyp(AF.x-P.x,AF.y-P.y)<2200&&P.al<.15&&P.v<P.d.sp*.7&&RM.gt<=0){RM.gt=6;say2('gear','Шасси!','Gear, gear')}}
window.rxPress=rxPress;
console.info('[v34] радар/ракеты/голос подключены');
})();
