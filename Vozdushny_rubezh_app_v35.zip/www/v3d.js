/* ===== Воздушный рубеж — 3D-режим (чистый WebGL, без библиотек) =====
   Читает то же состояние игры (P,E,A,G,M,BM,BUF,F,FX,PK,AF...) и рисует его в 3D.
   Модели: процедурные из контуров игры; если в www/models/ лежат .glb — берутся они (см. models/README.txt). */
(function(){
'use strict';
const ZS=900;                       // высота (al 0..1) -> метры сцены
const V3=window.V3={on:false,ok:false,so:0,cam:{x:0,y:0,z:300,yaw:0},models:{},ver:'1'};
const $=id=>document.getElementById(id);
/* ---------- математика (колонко-мажорные 4x4) ---------- */
const sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],
cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],
nrm=a=>{const l=Math.hypot(a[0],a[1],a[2])||1;return[a[0]/l,a[1]/l,a[2]/l]};
const mul=(a,b)=>{const o=new Array(16);for(let i=0;i<4;i++)for(let j=0;j<4;j++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+j]*b[i*4+k];o[i*4+j]=s}return o};
const persp=(f,a,n,fa)=>{const t=1/Math.tan(f/2),r=1/(n-fa);return[t/a,0,0,0,0,t,0,0,0,0,(n+fa)*r,-1,0,0,2*n*fa*r,0]};
const look=(e,c,u)=>{const z=nrm(sub(e,c)),x=nrm(cross(u,z)),y=cross(z,x);return[x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,e),-dot(y,e),-dot(z,e),1]};
const Rz=a=>{const c=Math.cos(a),s=Math.sin(a);return[c,s,0,0,-s,c,0,0,0,0,1,0,0,0,0,1]},
Ry=a=>{const c=Math.cos(a),s=Math.sin(a);return[c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1]},
Rx=a=>{const c=Math.cos(a),s=Math.sin(a);return[1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1]};
const Tr=(x,y,z)=>[1,0,0,0,0,1,0,0,0,0,1,0,x,y,z,1];
const Sc=(a,b,c)=>[a,0,0,0,0,b,0,0,0,0,c,0,0,0,0,1];
const IDM=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
// положение: game(x,y,al) -> GL (x,-y,z); heading a (game) -> yaw=-a
const orient=(x,y,z,a,pitch,roll,s)=>{let m=mul(Rz(-a),mul(Ry(-(pitch||0)),Rx(roll||0)));if(s!=null&&s!==1)for(let i=0;i<12;i++)m[i]*=s;m[12]=x;m[13]=-y;m[14]=z;return m};
const xf=(m,p)=>[m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]];
const hexc=h=>{if(!h||h[0]!='#')return[.6,.6,.6];if(h.length==4)h='#'+h[1]+h[1]+h[2]+h[2]+h[3]+h[3];return[1,3,5].map(i=>parseInt(h.substr(i,2),16)/255)};
const shd=(c,k)=>c.map(v=>Math.min(1,v*k));
const cl=(v,a,b)=>v<a?a:v>b?b:v,lerp=(a,b,t)=>a+(b-a)*t;
const wrp=a=>{while(a>Math.PI)a-=6.2832;while(a<-Math.PI)a+=6.2832;return a};
/* ---------- WebGL ---------- */
let cv3=null,gl=null;
function initGL(){
 cv3=document.createElement('canvas');cv3.id='c3';cv3.style.display='none';
 const c2=$('c');c2.parentNode.insertBefore(cv3,c2);
 gl=cv3.getContext('webgl',{antialias:true,alpha:false,powerPreference:'high-performance'})||cv3.getContext('experimental-webgl');
 if(!gl)return false;
 gl.getExtension('OES_element_index_uint');
 return true}
const HP='#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n';
function prog(vs,fs){const p=gl.createProgram();for(const[t,s]of[[gl.VERTEX_SHADER,vs],[gl.FRAGMENT_SHADER,HP+fs]]){const h=gl.createShader(t);gl.shaderSource(h,s);gl.compileShader(h);if(!gl.getShaderParameter(h,gl.COMPILE_STATUS))console.error('v3d shader:',gl.getShaderInfoLog(h));gl.attachShader(p,h)}gl.linkProgram(p);p.u={};p.a={};return p}
const U=(p,n)=>p.u[n]!==undefined?p.u[n]:(p.u[n]=gl.getUniformLocation(p,n));
const AT=(p,n)=>p.a[n]!==undefined?p.a[n]:(p.a[n]=gl.getAttribLocation(p,n));
let PGM,PGT,PGS,PGP;
function initProgs(){
/* меши: pos3 nrm3 col3 mat1 uv2 = 12 float */
PGM=prog(`attribute vec3 aP,aN,aC;attribute float aM;attribute vec2 aU;uniform mat4 uVP,uM;varying vec3 vP,vN,vC;varying float vM;varying vec2 vU;
void main(){vec4 w=uM*vec4(aP,1.);vP=w.xyz;vN=mat3(uM[0].xyz,uM[1].xyz,uM[2].xyz)*aN;vC=aC;vM=aM;vU=aU;gl_Position=uVP*w;}`,
`varying vec3 vP,vN,vC;varying float vM;varying vec2 vU;uniform vec3 uE,uL,uFc,uTint;uniform float uFog,uSun,uNf,uUseTex,uAlpha,uEm,uBlend;uniform sampler2D uTex;
void main(){vec3 N=normalize(vN),V=normalize(uE-vP),L=normalize(uL);if(dot(N,V)<0.)N=-N;vec4 tx=vec4(1.);if(uUseTex>.5){tx=texture2D(uTex,vU);if(uBlend<.5&&tx.a<.4)discard;}
vec3 base=vC*tx.rgb*uTint;float d=max(dot(N,L),0.),up=N.z*.5+.5;
vec3 amb=mix(vec3(.15,.16,.19),vec3(.5,.62,.8),up)*mix(.32,1.,uSun);
vec3 c=base*(amb*.85+d*vec3(1.,.93,.82)*.85*uSun);vec3 R=reflect(-V,N);
vec3 env=mix(vec3(.25,.27,.3),vec3(.62,.8,1.),smoothstep(-.3,.5,R.z))*mix(.3,1.,uSun)+pow(max(dot(R,L),0.),24.)*vec3(1.,.9,.7)*uSun;
float fr=pow(1.-max(dot(N,V),0.),3.),sp=pow(max(dot(N,normalize(L+V)),0.),vM<1.5?90.:48.);
if(vM<.5)c+=env*(.04+.22*fr)+sp*.22*uSun;else if(vM<1.5)c=mix(base*.3,env,.5+.4*fr)+sp*1.1*uSun;else if(vM<2.5)c=vec3(1.,.55,.2)*(1.1+.5*fr);else if(vM>5.5&&vM<6.5)c=base*(.5+.5*uSun)+vec3(1.,.85,.5)*uNf*.9;else c*=.95;
c+=uEm*vec3(1.,.5,.2);
c=1.-exp(-c*1.35);float f=1.-exp(-length(uE-vP)*uFog);c=mix(c,uFc,clamp(f,0.,1.));gl_FragColor=vec4(c,uAlpha*(uUseTex>.5?tx.a:1.));}`);
/* рельеф: pos3 uv2 col3 w1 */
PGT=prog(`attribute vec3 aP,aC;attribute vec2 aU;attribute float aW;uniform mat4 uVP;varying vec3 vP,vC;varying vec2 vU;varying float vW;
void main(){vP=aP;vC=aC;vU=aU;vW=aW;gl_Position=uVP*vec4(aP,1.);}`,
`varying vec3 vP,vC;varying vec2 vU;varying float vW;uniform vec3 uE,uL,uFc;uniform float uFog,uSun,uNf,uT,uUse;uniform sampler2D uTex;
void main(){vec3 c=uUse>.5?texture2D(uTex,vU).rgb:vC;vec3 V=normalize(uE-vP);
if(vW>.5){vec2 q=vP.xy*.011;vec3 n=normalize(vec3(sin(q.x*1.3+uT*.9+sin(q.y*2.3))*.035+sin(q.y*3.1-uT*.7)*.03,cos(q.y*1.7+uT*.8+sin(q.x*1.9))*.035+cos(q.x*2.9+uT*.5)*.03,1.));
 vec3 R=reflect(-V,n);float s=pow(max(dot(R,normalize(uL)),0.),110.);float fr=pow(1.-max(V.z,0.),4.);
 c=c+vec3(1.,.92,.75)*s*.8*uSun+mix(vec3(0.),vec3(.55,.72,.9)*mix(.25,1.,uSun),fr*.4)*vW;}
float dd=length(uE-vP);float f=1.-exp(-dd*uFog);f=clamp(f*1.0,0.,1.);c=mix(c,uFc,f);gl_FragColor=vec4(c,1.);}`);
PGS=prog(`attribute vec2 aP;varying vec2 vU;void main(){vU=aP;gl_Position=vec4(aP,.9999,1.);}`,
`varying vec2 vU;uniform vec3 uF,uR,uUp,uL,uHz,uZe;uniform vec2 uT;uniform float uNf;
void main(){vec3 d=normalize(uF+vU.x*uT.x*uR+vU.y*uT.y*uUp);float h=clamp(d.z,0.,1.);
vec3 c=mix(uHz,uZe,pow(h,.55));float s=max(dot(d,normalize(uL)),0.);
c+=vec3(1.,.9,.7)*(pow(s,500.)*3.+pow(s,8.)*.2)*(1.-uNf*.85);
if(uNf>.3){vec2 g=floor(d.xy/(.012+h*.02)+d.z*400.);float st=fract(sin(dot(g,vec2(12.9,78.2)))*43758.5);c+=vec3(1.)*step(.9975,st)*(uNf-.3)*h*1.4;}
if(d.z<0.)c=uHz;gl_FragColor=vec4(c,1.);}`);
/* частицы: pos3 uv2 col4 */
PGP=prog(`attribute vec3 aP;attribute vec2 aU;attribute vec4 aC;uniform mat4 uVP;varying vec2 vU;varying vec4 vC;varying float vD;
void main(){vU=aU;vC=aC;vec4 p=uVP*vec4(aP,1.);vD=p.w;gl_Position=p;}`,
`varying vec2 vU;varying vec4 vC;varying float vD;uniform sampler2D uTex;uniform float uFog;uniform float uAdd;uniform vec3 uFc;
void main(){vec4 t=texture2D(uTex,vU);vec4 c=t*vC;float f=clamp(1.-exp(-vD*uFog),0.,1.);
if(uAdd>.5){c.rgb*=(1.-f);gl_FragColor=vec4(c.rgb*c.a,0.);}else{c.rgb=mix(c.rgb,uFc,f*.8);gl_FragColor=c;}}`);
}
/* ---------- атлас спрайтов ---------- */
let ATL=null;
function mkAtlas(){
 const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');
 const cell=(i,fn)=>{g.save();g.translate((i%4)*64,((i/4)|0)*64);g.beginPath();g.rect(0,0,64,64);g.clip();fn();g.restore()};
 cell(0,()=>{const r=g.createRadialGradient(32,32,0,32,32,31);r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.25,'rgba(255,255,255,.55)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,64,64)});
 cell(1,()=>{let s=7;const rn=()=>(s=(s*16807)%2147483647)/2147483647;for(let i=0;i<14;i++){const x=32+(rn()-.5)*30,y=32+(rn()-.5)*30,r=9+rn()*10;const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,'rgba(255,255,255,.4)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,6.3);g.fill()}});
 cell(2,()=>{const r=g.createRadialGradient(32,32,0,32,32,31);r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.4,'rgba(255,255,255,.8)');r.addColorStop(.75,'rgba(255,255,255,.25)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,64,64)});
 cell(3,()=>{g.fillStyle='#fff';g.beginPath();g.arc(32,32,30,0,6.3);g.fill()});
 cell(4,()=>{g.strokeStyle='#fff';g.lineWidth=5;g.beginPath();g.arc(32,32,27,0,6.3);g.stroke();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=9;g.beginPath();g.arc(32,32,26,0,6.3);g.stroke()});
 cell(5,()=>{let s=19;const rn=()=>(s=(s*16807)%2147483647)/2147483647;for(let i=0;i<22;i++){const a=rn()*6.28,d=rn()*17,x=32+Math.cos(a)*d,y=34+Math.sin(a)*d*.7,r=8+rn()*10;const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,'rgba(255,255,255,.34)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,6.3);g.fill()}});
 cell(6,()=>{const q=g.createLinearGradient(0,0,64,0);q.addColorStop(0,'rgba(255,255,255,0)');q.addColorStop(.15,'rgba(255,255,255,.9)');q.addColorStop(.85,'rgba(255,255,255,.9)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,22,64,20)});
 cell(7,()=>{const r=g.createRadialGradient(32,32,10,32,32,31);r.addColorStop(0,'rgba(255,255,255,.07)');r.addColorStop(.8,'rgba(255,255,255,.22)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,64,64)});
 ATL=mktex(c,false)}
function mktex(src,rep){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,src);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);const w=rep?gl.REPEAT:gl.CLAMP_TO_EDGE;gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,w);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,w);return t}
/* ---------- построитель мешей ---------- */
let BUF=[],YF=1;
const vtx=(p,n,c,m,u,v)=>BUF.push(p[0],p[1]*YF,p[2],n[0],n[1]*YF,n[2],c[0],c[1],c[2],m,u||0,v||0);
const tri=(a,b,c,col,m,hint)=>{let n=nrm(cross(sub(b,a),sub(c,a)));if(hint&&dot(n,hint)<0)n=[-n[0],-n[1],-n[2]];for(const p of[a,b,c])vtx(p,n,col,m)};
const cr2=(a,b,c)=>(b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]);
const inT=(p,a,b,c)=>{const d1=cr2(a,b,p),d2=cr2(b,c,p),d3=cr2(c,a,p);return d1>=-1e-9&&d2>=-1e-9&&d3>=-1e-9};
function ear(P){const idx=P.map((_,i)=>i),out=[];let g=0;while(idx.length>3&&g++<400){let cut=0;for(let i=0;i<idx.length;i++){const a=idx[(i+idx.length-1)%idx.length],b=idx[i],c=idx[(i+1)%idx.length];if(cr2(P[a],P[b],P[c])<=1e-9)continue;let ok=1;for(const j of idx)if(j!=a&&j!=b&&j!=c&&inT(P[j],P[a],P[b],P[c])){ok=0;break}if(ok){out.push([a,b,c]);idx.splice(i,1);cut=1;break}}if(!cut)break}if(idx.length==3)out.push(idx.slice());return out}
function slab(pts,to3,th,col,m){let P=pts.filter((p,i)=>{const q=pts[(i+1)%pts.length];return Math.hypot(p[0]-q[0],p[1]-q[1])>1e-3});if(P.length<3)return;
 let A=0;P.forEach((p,i)=>{const q=P[(i+1)%P.length];A+=p[0]*q[1]-q[0]*p[1]});if(A<0)P=P.slice().reverse();
 const T=P.map(p=>to3(p[0],p[1],th(p[0],p[1])/2)),Bt=P.map(p=>to3(p[0],p[1],-th(p[0],p[1])/2)),up=sub(to3(0,0,1),to3(0,0,0)),dn=[-up[0],-up[1],-up[2]];
 const cen=[0,1,2].map(k=>T.reduce((s,p,i)=>s+(p[k]+Bt[i][k])/2,0)/T.length);
 for(const[a,b,c]of ear(P)){tri(T[a],T[b],T[c],col,m,up);tri(Bt[a],Bt[b],Bt[c],shd(col,.8),m,dn)}
 for(let i=0;i<P.length;i++){const j=(i+1)%P.length,mid=[0,1,2].map(k=>(T[i][k]+T[j][k]+Bt[i][k]+Bt[j][k])/4),h=sub(mid,cen);tri(Bt[i],Bt[j],T[j],shd(col,.9),m,h);tri(Bt[i],T[j],T[i],shd(col,.9),m,h)}}
function ellip(cx,cy,cz,rx,ry,rz,col,m,half){const NL=7,NR=16,g=[];const f0=half?0:-Math.PI/2;for(let i=0;i<=NL;i++){const f=f0+i/NL*(Math.PI/2-f0),r=[];for(let j=0;j<=NR;j++){const l=j/NR*Math.PI*2,cf=Math.cos(f),n=nrm([cf*Math.cos(l)/rx,cf*Math.sin(l)/ry,Math.sin(f)/rz]);r.push([[cx+rx*cf*Math.cos(l),cy+ry*cf*Math.sin(l),cz+rz*Math.sin(f)],n])}g.push(r)}
 for(let i=0;i<NL;i++)for(let j=0;j<NR;j++){const a=g[i][j],b=g[i][j+1],c=g[i+1][j+1],d=g[i+1][j];for(const t of[[a,b,c],[a,c,d]])for(const v of t)vtx(v[0],v[1],col,m)}}
function disc(cx,cy,cz,ry,rz,nx,col,m){const N=14;for(let i=0;i<N;i++){const a=i/N*6.2832,b=(i+1)/N*6.2832;tri([cx,cy,cz],[cx,cy+ry*Math.cos(a),cz+rz*Math.sin(a)],[cx,cy+ry*Math.cos(b),cz+rz*Math.sin(b)],col,m,[nx,0,0])}}
function tube(x0,x1,cy,cz,r0,r1,col,m,N){N=N||14;for(let i=0;i<N;i++){const a=i/N*6.2832,b=(i+1)/N*6.2832,P=(x,r,t)=>[x,cy+r*Math.cos(t),cz+r*Math.sin(t)];const h=[0,Math.cos(a+3.1416/N),Math.sin(a+3.1416/N)];tri(P(x0,r0,a),P(x1,r1,a),P(x1,r1,b),col,m,h);tri(P(x0,r0,a),P(x1,r1,b),P(x0,r0,b),col,m,h)}}
// ось z: цилиндр/конус
function cylz(cx,cy,z0,z1,r0,r1,col,m,N,cap){N=N||12;for(let i=0;i<N;i++){const a=i/N*6.2832,b=(i+1)/N*6.2832,P=(z,r,t)=>[cx+r*Math.cos(t),cy+r*Math.sin(t),z];const h=[Math.cos(a+3.1416/N),Math.sin(a+3.1416/N),0];tri(P(z0,r0,a),P(z1,r1,a),P(z1,r1,b),col,m,h);tri(P(z0,r0,a),P(z1,r1,b),P(z0,r0,b),col,m,h);
  if(cap){tri([cx,cy,z1],P(z1,r1,a),P(z1,r1,b),col,m,[0,0,1])}}}
function box(cx,cy,cz,sx,sy,sz,col,m,k){const x=sx/2,y=sy/2,z=sz/2;k=k||[1,.8,.9,.9,.85,.85];
 const F=[[[1,0,0],[[x,-y,-z],[x,y,-z],[x,y,z],[x,-y,z]],0],[[-1,0,0],[[-x,y,-z],[-x,-y,-z],[-x,-y,z],[-x,y,z]],1],[[0,1,0],[[x,y,-z],[-x,y,-z],[-x,y,z],[x,y,z]],2],[[0,-1,0],[[-x,-y,-z],[x,-y,-z],[x,-y,z],[-x,-y,z]],3],[[0,0,1],[[-x,-y,z],[x,-y,z],[x,y,z],[-x,y,z]],4],[[0,0,-1],[[-x,y,-z],[x,y,-z],[x,-y,-z],[-x,-y,-z]],5]];
 for(const[n,q,i]of F){const c=shd(col,k[i]),P=q.map(p=>[p[0]+cx,p[1]+cy,p[2]+cz]);for(const t of[[0,1,2],[0,2,3]])for(const v of t)vtx(P[v],n,c,m)}}
// призма-«домик» вдоль x: крыша с коньком
function gable(cx,cy,cz,sx,sy,sz,rh,col,rc,m){box(cx,cy,cz,sx,sy,sz,col,m);const x=sx/2,y=sy/2,z0=cz+sz/2;const P=(a,b,c)=>[cx+a,cy+b,z0+c];
 tri(P(-x,-y,0),P(x,-y,0),P(x,0,rh),rc,m,[0,-1,1]);tri(P(-x,-y,0),P(x,0,rh),P(-x,0,rh),rc,m,[0,-1,1]);tri(P(-x,y,0),P(x,0,rh),P(x,y,0),rc,m,[0,1,1]);tri(P(-x,y,0),P(-x,0,rh),P(x,0,rh),rc,m,[0,1,1]);
 tri(P(x,-y,0),P(x,y,0),P(x,0,rh),shd(col,.9),m,[1,0,0]);tri(P(-x,-y,0),P(-x,0,rh),P(-x,y,0),shd(col,.9),m,[-1,0,0])}
function bodyRev(poly,x0,x1,col,dark){ // фюзеляж вращения по контуру (как в прототипе)
 const NS=44,NR=20,W=[];
 for(let i=0;i<=NS;i++){const x=x0+(x1-x0)*i/NS;let w=0;for(let k=0;k<poly.length;k++){const a=poly[k],b=poly[(k+1)%poly.length];if((a[0]-x)*(b[0]-x)<=0){if(a[0]==b[0])w=Math.max(w,Math.abs(a[1]),Math.abs(b[1]));else{const t=(x-a[0])/(b[0]-a[0]);w=Math.max(w,Math.abs(a[1]+(b[1]-a[1])*t))}}}W.push(w)}
 const hu=w=>w*.82+.25,hd=w=>w*.66+.2,e=2.5,g=[];
 for(let i=0;i<=NS;i++){const x=x0+(x1-x0)*i/NS,w=Math.max(.04,W[i]),r=[];for(let j=0;j<=NR;j++){const t=j/NR*6.2832,c=Math.cos(t),s=Math.sin(t),ey=Math.sign(c)*Math.pow(Math.abs(c),2/e),ez=Math.sign(s)*Math.pow(Math.abs(s),2/e);r.push([x,w*ey,(s>0?hu(w):hd(w))*ez])}g.push(r)}
 const P=(i,j)=>g[Math.max(0,Math.min(NS,i))][j];
 for(let i=0;i<=NS;i++)for(let j=0;j<=NR;j++){const a=sub(P(i+1,j),P(i-1,j)),b=sub(P(i,(j+1)%NR),P(i,(j+NR-1)%NR));let n=nrm(cross(a,b));const p=g[i][j];if(Math.hypot(n[0],n[1],n[2])<.5||dot(n,[0,p[1],p[2]])<0)n=nrm([i==0?-1:i==NS?1:0,p[1],p[2]]);g[i][j].n=n}
 const L=x1-x0;
 for(let i=0;i<NS;i++)for(let j=0;j<NR;j++){const q=[g[i][j],g[i][j+1],g[i+1][j+1],g[i+1][j]];const x=q[0][0],k=q[0][2]<0?.78:1,c=x>x1-.15*L?dark:shd(col,k);for(const t of[[0,1,2],[0,2,3]])for(const v of t)vtx(q[v],q[v].n,c,0)}
 return{W,x0,x1,hu}}
/* самолёт из контуров игры (SH/SD) */
function buildJet(sh,colHex){BUF=[];YF=1;const S=SH[sh],sd=SD[sh]||{},col=hexc(colHex),dk=[.13,.14,.16];
 let x0=1e9,x1=-1e9;for(const s of S)for(const p of s[0]){x0=Math.min(x0,p[0]);x1=Math.max(x1,p[0])}const L=x1-x0;
 const bp=S.filter(s=>s[2]==0)[0][0],bo=bodyRev(bp,x0,x1,col,dk),wz=-.4;
 for(const s of S){const k=s[2];if(k==1||k==4||k==3){const c=k==4?shd(col,.78):shd(col,.95);const Y=Math.max(...s[0].map(p=>Math.abs(p[1])))||1;
  for(const sg of[1,-1])slab(s[0].map(p=>[p[0],p[1]*sg]),(u,v,w)=>[u,v,wz+w+Math.abs(v)*.035],(u,v)=>.35+.9*Math.max(0,1-Math.abs(v)/Y)*Math.max(0,1-Math.abs(v)/Y*.2),c,0)}}
 const cp=sd.cp||[x0+.68*L,.17*L,.04*L],ci=Math.floor((cp[0]-x0)/L*44),wc=Math.max(...bo.W.slice(Math.max(0,ci-1),ci+2),.5),zt=bo.hu(wc);
 ellip(cp[0],0,zt*.55,cp[1]/2,Math.min(cp[2],wc*.8),zt*.55+.5,[.1,.2,.3],1,1);
 const fn=sd.fn||[[x0+.34*L,0,x0+.04*L,0,1.2]];
 for(const f of fn){const c=Math.abs(f[0]-f[2]),H=Math.min(10,.5*c+1),tw=Math.max(.5,f[4]*.5),xf=Math.max(f[0],f[2]),xr=Math.min(f[0],f[2]),zb=bo.hu(Math.max(.5,bo.W[Math.max(0,Math.min(44,Math.floor((xr+c*.5-x0)/L*44)))]||1))*.6;
  const pr=[[xf,0],[xr,0],[xr+.06*c,H],[xf-.6*c,H]];for(const sg of f[1]?[1,-1]:[1])slab(pr,(u,v,w)=>[u,sg*f[1]+w,zb+v],(u,v)=>tw*(1-.5*v/H),shd(col,.95),0)}
 for(const t of sd.it||[])for(const sg of t[1]?[1,-1]:[1])disc(t[0]+.05,sg*t[1],0,Math.max(.6,t[2]),Math.max(.6,t[3]),1,[.03,.03,.04],3);
 for(const t of sd.ex||[[x0+1,0,.034*L]])for(const sg of t[1]?[1,-1]:[1]){tube(t[0]+3,t[0],sg*t[1],0,t[2]*1.05,t[2]*.85,[.2,.2,.22],3);disc(t[0]-.1,sg*t[1],0,t[2]*.8,t[2]*.8,-1,[.9,.45,.2],2)}
 return{v:new Float32Array(BUF),L,x0,x1,sd}}
/* ракета по MSP */
function buildMissile(id){BUF=[];YF=1;const s=MSP[id]||MSP.sam,k=s.k,L=s.L*k,r0=s.d/2*k*(s.f||1.3)*1.1,xm=m=>(m-s.L/2)*k;
 const prof=[];const sec=s.sec||[[0,s.L,s.c]];const nose=Math.max(.15*s.L,(s.nl||.2)*s.L);
 for(const[a,b,c]of sec){const cc=hexc(c);const xa=xm(a),xb=xm(Math.min(b,s.L-nose));if(xb>xa)tube(xa,xb,0,0,r0,r0,cc,0,12)}
 const nc=hexc(s.n||'#444');const xn=xm(s.L-nose);tube(xn,xm(s.L),0,0,r0,r0*.12,nc,0,12);
 tube(xm(0),xm(0)+.1,0,0,r0*.8,r0*.6,[.2,.2,.2],3,10);
 if(s.bst){const bl=s.bst.len*k,br=s.bst.d/2*k*(s.f||1.3);tube(xm(0)-bl*.4,xm(0)+bl*.6,0,0,br,br,hexc(s.bst.c||'#8a8f93'),0,12)}
 for(const f of s.fins||[]){const[xt,ch,sp,sw,tc,col]=f,x=xm(xt),C=ch*k,S=sp*k*1.25,SW=sw*k,TC=tc*k,cc=hexc(col||'#aaa');
  for(let q=0;q<4;q++){const an=q*Math.PI/2+Math.PI/4;const pts=[[x,0],[x+C,0],[x+SW+TC,S],[x+SW,S]];
   const ca=Math.cos(an),sa=Math.sin(an);slab(pts.map(p=>[p[0],p[1]]),(u,v,w)=>[u,r0*.8*ca+v*ca-w*sa,r0*.8*sa+v*sa+w*ca],()=>.35*k*.12+.1,cc,0)}}
 return{v:new Float32Array(BUF),L,x0:-L/2,x1:L/2}}
function buildBomb(id){BUF=[];YF=1;const s=BS[id]||BS.mk82,L=s.L,r=s.r,c=hexc(s.c),h=L/2;
 const N=12;for(let i=0;i<N;i++){}
 tube(-h+L*.3,h-L*.15,0,0,r,r,c,0,12);tube(h-L*.15,h,0,0,r,r*.25,c,0,12);tube(-h,-h+L*.3,0,0,r*.45,r,c,0,12);
 for(let q=0;q<4;q++){const an=q*Math.PI/2,ca=Math.cos(an),sa=Math.sin(an);slab([[-h-1,0],[-h+L*.3,0],[-h+L*.3,r*1.9],[-h-1,r*1.9]],(u,v,w)=>[u,(r*.3+v)*ca-w*sa,(r*.3+v)*sa+w*ca],()=>.5,shd(c,.8),0)}
 return{v:new Float32Array(BUF),L,x0:-h,x1:h}}
/* вертолёт: использует buildJet для корпуса; ротор динамический */
function buildBlades(R,n,col){BUF=[];YF=1;for(let i=0;i<n;i++){const a=i*6.2832/n;slab([[0,-.5],[R,-.35],[R,.35],[0,.5]],(u,v,w)=>[Math.cos(a)*u-Math.sin(a)*v,Math.sin(a)*u+Math.cos(a)*v,w],()=>.18,col,3)}cylz(0,0,-1.5,1.2,1.6,1.1,[.12,.12,.14],3,10,1);return{v:new Float32Array(BUF),L:R*2}}
function buildProp(R,n){return buildBlades(R,n,[.1,.1,.11])}
/* ---------- наземные объекты (в игровых координатах x вперёд, y вправо/вниз) ---------- */
const GM={};
function gnd(name,fn){BUF=[];YF=-1;fn();YF=1;return{v:new Float32Array(BUF),L:0}}
const C_={tan:[.36,.4,.28],tan2:[.26,.29,.2],dk:[.12,.13,.14],gry:[.45,.47,.5],lg:[.62,.64,.66],rd:[.62,.2,.16],wh:[.85,.86,.84],gr:[.32,.4,.26],br:[.55,.4,.28],bl:[.2,.34,.52],ye:[.84,.7,.2],rf:[.5,.28,.22]};
const GB={
 tank:()=>gnd('tank',()=>{box(0,0,5,40,24,6,C_.tan,4);box(0,-14,3.5,40,5,7,C_.dk,3);box(0,14,3.5,40,5,7,C_.dk,3);box(-4,0,11,18,14,5,C_.tan2,4);box(-7,0,13,8,6,2.5,C_.tan2,4)}),
 tankT:()=>gnd('tankT',()=>{tube(0,26,0,0,1.5,1.2,C_.dk,3,8)}),
 truck:()=>gnd('truck',()=>{box(8,0,7,14,12,8,C_.gr,4);box(-8,0,8,22,13,10,C_.tan2,4);for(const x of[-14,-2,10])for(const y of[-7,7])box(x,y,2.4,5,2.6,5,C_.dk,3);box(13,0,9,2,10,4,[.15,.25,.35],1)}),
 fuel:()=>gnd('fuel',()=>{tube(-14,14,0,8,6.5,6.5,C_.ye,4,12);for(const x of[-12,0,12])for(const y of[-7,7])box(x,y,2.4,5,2.6,5,C_.dk,3);box(0,0,3.5,32,10,3,C_.dk,3);disc(14,0,8,6.5,6.5,1,C_.ye,4)}),
 aaa:()=>gnd('aaa',()=>{cylz(0,0,0,4,11,10,C_.gr,4,12,1);box(0,0,3,18,18,2.5,C_.dk,3);for(const[x,y]of[[-10,-10],[10,-10],[-10,10],[10,10]])cylz(x,y,0,3,1.8,1.8,C_.dk,3,6)}),
 aaaT:()=>gnd('aaaT',()=>{box(0,0,8,12,14,7,C_.tan2,4);for(const y of[-4,4])tube(2,30,y,10,1,.8,C_.dk,3,8)}),
 mpad:()=>gnd('mpad',()=>{for(const a of[0,2.1,4.2])tube(0,1,0,0,.1,.1,C_.dk,3,4);cylz(0,0,0,4,3,3,C_.tan2,4,8,1);box(0,0,.8,13,13,1.6,C_.gr,4)}),
 mpadT:()=>gnd('mpadT',()=>{tube(-4,14,0,0,1.6,1.6,C_.tan,4,8);box(0,0,-2,6,3,5,C_.dk,3)}),
 radarB:()=>gnd('radarB',()=>{box(0,0,5,26,22,10,C_.gr,4);cylz(0,0,10,22,3.2,3.2,C_.gry,4,8);box(-8,0,2,8,8,4,C_.dk,3)}),
 radarD:()=>gnd('radarD',()=>{// параболоид-«тарелка» поставлена на ребро (смотрит вдоль +x)
   const NR=14,NS=5,g=[];for(let i=0;i<=NS;i++){const r=i/NS*17,x=-.012*r*r;const row=[];for(let j=0;j<=NR;j++){const t=j/NR*6.2832;row.push([x,Math.cos(t)*r,Math.sin(t)*r*.62])}g.push(row)}
   for(let i=0;i<NS;i++)for(let j=0;j<NR;j++){const a=g[i][j],b=g[i][j+1],c=g[i+1][j+1],d=g[i+1][j];tri(a,b,c,C_.lg,4,[1,0,0]);tri(a,c,d,C_.lg,4,[1,0,0])}
   tube(0,6,0,0,.7,.7,C_.dk,3,6)}),
 sam:()=>gnd('sam',()=>{box(0,0,3,30,26,5,C_.gr,4);for(const y of[-9,9])box(-6,y,2,14,3,4,C_.dk,3);box(-10,0,8,10,12,7,C_.tan2,4)}),
 samT:()=>gnd('samT',()=>{box(0,0,0,40,4,3,C_.gry,4);for(const y of[-8,8]){tube(-14,26,y,3,2.2,2.2,C_.lg,0,10);tube(26,34,y,3,2.2,.3,C_.rd,0,10);for(let q=0;q<4;q++){const an=q*1.5708;slab([[-14,0],[-8,0],[-9,4],[-14,4]],(u,v,w)=>[u,y+(2.2+v)*Math.cos(an)-w*Math.sin(an),3+(2.2+v)*Math.sin(an)+w*Math.cos(an)],()=>.3,C_.gry,0)}}}),
 depot:()=>gnd('depot',()=>{gable(0,-8,7,70,30,14,10,C_.tan,C_.rf,4);gable(-14,28,6,40,26,12,8,C_.lg,C_.gry,4);for(const[x,y]of[[34,22],[40,30]])cylz(x,y,0,14,5,5,C_.wh,4,10,1);box(26,-28,3,18,10,6,C_.br,4)}),
 ship:()=>gnd('ship',()=>{const hull=[[56,0],[42,-13],[28,-14],[-48,-13],[-54,-9],[-54,9],[-48,13],[28,14],[42,13]];slab(hull,(u,v,w)=>[u,-v,5+w],()=>14,[.38,.42,.46],4);
   slab(hull.map(p=>[p[0]*.97,p[1]*.97]),(u,v,w)=>[u,-v,12+w],()=>.6,[.5,.52,.54],4);
   box(-8,0,17,40,16,8,C_.lg,4);box(-4,0,24,22,12,7,C_.gry,4);box(-2,0,32,8,8,8,C_.lg,4);cylz(-2,0,36,56,.8,.5,C_.dk,3,5,1);box(-30,0,16,10,8,5,C_.gry,4);
   tube(22,38,0,19,1.6,1.4,C_.dk,3,8);cylz(18,0,13,18,5,4,C_.gry,4,10,1);box(-40,0,15,9,10,4,C_.gry,4)}),
 bridge:(len)=>gnd('bridge',()=>{const L=len||170;box(0,0,18,L,24,4,C_.gry,4);box(0,-12,22,L,1.5,3,C_.lg,4);box(0,12,22,L,1.5,3,C_.lg,4);for(let x=-L/2+10;x<=L/2-8;x+=L/4){for(const y of[-8,8])box(x,y,8,5,5,18,C_.gry,4)}for(let x=-L/2;x<=L/2;x+=17)box(x,0,18,.6,24.4,4.2,C_.dk,3)}),
 bld0:()=>gnd('bld0',()=>{box(0,0,14,26,26,28,[.68,.64,.56],6);box(0,0,29.5,28,28,3,C_.dk,4)}),
 bld1:()=>gnd('bld1',()=>{gable(0,0,11,36,24,22,9,[.7,.55,.42],C_.rf,6)}),
 bld2:()=>gnd('bld2',()=>{box(0,0,20,22,22,40,[.55,.6,.66],6);box(0,0,41.5,24,24,3,C_.dk,4);box(8,8,45,4,4,6,C_.gry,4)}),
 pilot:()=>gnd('pilot',()=>{cylz(0,0,0,5,1.6,1.6,[.95,.5,.1],4,6,1);ellip(0,0,6.5,1.6,1.6,1.6,[.9,.75,.6],4,0)}),
 hangar:()=>gnd('hangar',()=>{gable(0,0,9,90,50,18,12,C_.lg,C_.gry,4)}),
 tower:()=>gnd('tower',()=>{cylz(0,0,0,22,3.4,3.4,C_.wh,4,10,1);box(0,0,24,14,14,7,[.15,.25,.35],1);box(0,0,28.5,16,16,2,C_.gry,4)}),
 chute:()=>gnd('chute',()=>{ellip(0,0,0,16,16,9,[.95,.55,.12],4,1)}),
 /* вертолёт-цель (G.air) */
 pk:()=>gnd('pk',()=>{box(0,0,0,24,24,24,[.9,.9,.9],4);box(0,0,0,5,26,26,[1,1,1],4);box(0,0,0,26,5,26,[1,1,1],4)}),
};
/* авианосец и аэродром — строятся в координатах базы */
GB.carrier=()=>gnd('cv',()=>{const hull=[[300,0],[270,-36],[-290,-44],[-304,-30],[-304,30],[-290,44],[270,36]];slab(hull,(u,v,w)=>[u,-v,6+w],()=>24,[.34,.38,.43],4);
  const deck=[[310,0],[282,-48],[-296,-52],[-308,-34],[-308,34],[-296,52],[282,48]];slab(deck,(u,v,w)=>[u,-v,18.5+w],()=>3,[.28,.3,.32],4);
  box(0,0,20.2,520,1.6,.4,C_.wh,4);for(let x=-240;x<=240;x+=60)box(x,0,20.3,26,2.4,.3,C_.wh,4);box(-100,-30,20.3,240,1.3,.3,C_.ye,4);
  box(80,50,34,60,16,26,C_.gry,4);box(84,50,50,30,14,10,C_.lg,4);cylz(96,50,56,80,1,.6,C_.dk,3,5,1);box(70,50,66,10,8,4,C_.dk,3);
  for(const x of[-210,-150,-90])for(const s of[-1,1])box(x,s*52,17,22,3,3,C_.dk,3)});
GB.airbase=()=>gnd('af',()=>{box(0,0,.9,760,100,1.6,[.2,.21,.23],4);box(0,0,1.8,680,3,.3,C_.wh,4);box(0,-48,1.8,760,1.6,.3,C_.wh,4);box(0,48,1.8,760,1.6,.3,C_.wh,4);
  for(let i=0;i<4;i++){box(-366,-40+i*22,1.8,14,8,.3,C_.wh,4);box(366,-40+i*22,1.8,14,8,.3,C_.wh,4)}
  for(let x=-340;x<=340;x+=70)box(x,0,1.9,36,3.5,.3,C_.wh,4);
  box(0,-94,.8,320,76,1.2,[.34,.36,.38],4);box(0,-54,.8,48,10,1.2,[.3,.32,.34],4);box(0,64,.5,760,40,.8,[.26,.28,.3],4)});
/* ---------- модели: реестр, GLB-загрузчик ---------- */
const AKEYS=['f86','mig21','f4','su27','f22','su25','a10','su24','f111','mig29','f14','f15','su35','ah64','ka50','f117','tu160','b52','tu95','mi24','mi28','ah1','ka52','mig25','mig31','su34','f16','f35','tu22m','su57','mirage2000','rafale','tornado','typhoon','mig23','su25sm3','gripen','mig15'];
let SHKEY={};            // номер контура SH -> ключ модели
function initKeys(){PL.forEach((d,i)=>{SHKEY[d.sh]=AKEYS[i]||('plane'+i)})}
const MAN={};            // manifest.json
const GLB={};            // ключ -> модель из .glb
let glbLoading={};
const mkbuf=(arr)=>{const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,arr,gl.STATIC_DRAW);return b};
function mkModel(o){return{parts:[{buf:mkbuf(o.v),n:o.v.length/12,tex:null,blend:0}],L:o.L||0,x0:o.x0,x1:o.x1,sd:o.sd}}
const PROC={};           // процедурные кэш
function getProc(key,fn){return PROC[key]||(PROC[key]=mkModel(fn()))}
/* --- GLB --- */
const CT={5120:[1,Int8Array],5121:[1,Uint8Array],5122:[2,Int16Array],5123:[2,Uint16Array],5125:[4,Uint32Array],5126:[4,Float32Array]},NC={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16};
function readAcc(J,bin,i){const a=J.accessors[i],bv=J.bufferViews[a.bufferView||0],n=NC[a.type],[sz,Ar]=CT[a.componentType],off=(bv.byteOffset||0)+(a.byteOffset||0),st=bv.byteStride||n*sz,out=new Float32Array(a.count*n),dv=new DataView(bin.buffer,bin.byteOffset,bin.byteLength),norm=a.normalized;
 const get=a.componentType==5126?(o)=>dv.getFloat32(o,true):a.componentType==5123?(o)=>dv.getUint16(o,true):a.componentType==5125?(o)=>dv.getUint32(o,true):a.componentType==5121?(o)=>dv.getUint8(o):a.componentType==5122?(o)=>dv.getInt16(o,true):(o)=>dv.getInt8(o);
 const nf=norm?(a.componentType==5121?255:a.componentType==5123?65535:a.componentType==5120?127:a.componentType==5122?32767:1):1;
 for(let k=0;k<a.count;k++)for(let c=0;c<n;c++)out[k*n+c]=get(off+k*st+c*sz)/nf;return out}
function qmat(q,t,s){const[x,y,z,w]=q,x2=x+x,y2=y+y,z2=z+z,xx=x*x2,xy=x*y2,xz=x*z2,yy=y*y2,yz=y*z2,zz=z*z2,wx=w*x2,wy=w*y2,wz=w*z2;
 return[(1-(yy+zz))*s[0],(xy+wz)*s[0],(xz-wy)*s[0],0,(xy-wz)*s[1],(1-(xx+zz))*s[1],(yz+wx)*s[1],0,(xz+wy)*s[2],(yz-wx)*s[2],(1-(xx+yy))*s[2],0,t[0],t[1],t[2],1]}
async function parseGLB(ab,opt){
 const dv=new DataView(ab);if(dv.getUint32(0,true)!=0x46546C67)throw new Error('не GLB');
 let off=12,J=null,bin=null;while(off<ab.byteLength){const len=dv.getUint32(off,true),ty=dv.getUint32(off+4,true);const d=new Uint8Array(ab,off+8,len);if(ty==0x4E4F534A)J=JSON.parse(new TextDecoder().decode(d));else if(ty==0x004E4942)bin=d;off+=8+len}
 if(!J)throw new Error('нет JSON');if(!bin&&J.buffers&&J.buffers[0]&&J.buffers[0].uri&&J.buffers[0].uri.startsWith('data:')){const b64=J.buffers[0].uri.split(',')[1],s=atob(b64);bin=new Uint8Array(s.length);for(let i=0;i<s.length;i++)bin[i]=s.charCodeAt(i)}
 // текстуры
 const tex=[];if(J.textures)await Promise.all(J.textures.map(async(t,i)=>{try{const im=J.images[t.source];let blob;if(im.bufferView!==undefined){const bv=J.bufferViews[im.bufferView];blob=new Blob([bin.subarray(bv.byteOffset||0,(bv.byteOffset||0)+bv.byteLength)],{type:im.mimeType||'image/png'})}else if(im.uri&&im.uri.startsWith('data:')){blob=await (await fetch(im.uri)).blob()}if(blob){const bmp=await createImageBitmap(blob);tex[i]=bmp}}catch(e){tex[i]=null}}))
 const groups={};      // ключ материала -> {pos,nrm,uv,col,idx}
 const matOf=i=>{const m=(J.materials&&J.materials[i])||{},p=m.pbrMetallicRoughness||{};const bc=p.baseColorFactor||[1,1,1,1];return{c:bc,t:p.baseColorTexture?p.baseColorTexture.index:-1,blend:m.alphaMode=='BLEND'?1:0,em:m.emissiveFactor||null}};
 const scene=J.scenes[J.scene||0].nodes,verts=[];
 const walk=(ni,pm)=>{const n=J.nodes[ni];let m=n.matrix?n.matrix.slice():qmat(n.rotation||[0,0,0,1],n.translation||[0,0,0],n.scale||[1,1,1]);m=mul(pm,m);
  if(n.mesh!==undefined)for(const pr of J.meshes[n.mesh].primitives){if(pr.mode!==undefined&&pr.mode!==4)continue;const P=readAcc(J,bin,pr.attributes.POSITION),N=pr.attributes.NORMAL!==undefined?readAcc(J,bin,pr.attributes.NORMAL):null,T=pr.attributes.TEXCOORD_0!==undefined?readAcc(J,bin,pr.attributes.TEXCOORD_0):null,CC=pr.attributes.COLOR_0!==undefined?readAcc(J,bin,pr.attributes.COLOR_0):null,cn=CC?(J.accessors[pr.attributes.COLOR_0].type=='VEC4'?4:3):0;
   let I;if(pr.indices!==undefined)I=readAcc(J,bin,pr.indices);else{I=new Float32Array(P.length/3);for(let i=0;i<I.length;i++)I[i]=i}
   const mt=matOf(pr.material),key=mt.t+'|'+mt.blend+'|'+mt.c.join(',');const g=groups[key]||(groups[key]={mt,v:[]});
   const wp=i=>xf(m,[P[i*3],P[i*3+1],P[i*3+2]]),wn=i=>N?nrm([m[0]*N[i*3]+m[4]*N[i*3+1]+m[8]*N[i*3+2],m[1]*N[i*3]+m[5]*N[i*3+1]+m[9]*N[i*3+2],m[2]*N[i*3]+m[6]*N[i*3+1]+m[10]*N[i*3+2]]):null;
   for(let k=0;k<I.length;k+=3){const ids=[I[k],I[k+1],I[k+2]],ps=ids.map(wp);let fn=null;if(!N){fn=nrm(cross(sub(ps[1],ps[0]),sub(ps[2],ps[0])))}
    for(let q=0;q<3;q++){const id=ids[q],nn=N?wn(id):fn;const col=CC?[CC[id*cn],CC[id*cn+1],CC[id*cn+2]]:[1,1,1];g.v.push(ps[q][0],ps[q][1],ps[q][2],nn[0],nn[1],nn[2],col[0]*mt.c[0],col[1]*mt.c[1],col[2]*mt.c[2],T?T[id*2]:0,T?T[id*2+1]:0,mt.c[3])}}}
  for(const c of n.children||[])walk(c,m)};
 for(const r of scene)walk(r,IDM);
 // габариты в исходных осях
 let mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9];for(const k in groups){const v=groups[k].v;for(let i=0;i<v.length;i+=12)for(let a=0;a<3;a++){mn[a]=Math.min(mn[a],v[i+a]);mx[a]=Math.max(mx[a],v[i+a])}}
 if(mn[0]>1e8)throw new Error('пустая модель');
 // ориентация
 const up=opt.up||'y',ax={x:[1,0,0],y:[0,1,0],z:[0,0,1]};const ext=[mx[0]-mn[0],mx[1]-mn[1],mx[2]-mn[2]];
 const un=up.replace(/[+-]/,''),us=up[0]=='-'?-1:1,U=ax[un].map(v=>v*us);
 let fw=opt.fwd;if(!fw){const cand=['x','y','z'].filter(a=>a!=un);fw='+'+(ext[['x','y','z'].indexOf(cand[0])]>=ext[['x','y','z'].indexOf(cand[1])]?cand[0]:cand[1])}
 let Fv=ax[fw.replace(/[+-]/,'')].map(v=>v*(fw[0]=='-'?-1:1));
 if(opt.yaw){const a=opt.yaw*Math.PI/180,Lft=cross(U,Fv);Fv=[Fv[0]*Math.cos(a)+Lft[0]*Math.sin(a),Fv[1]*Math.cos(a)+Lft[1]*Math.sin(a),Fv[2]*Math.cos(a)+Lft[2]*Math.sin(a)]}
 const Lf=cross(U,Fv);const ctr=[(mn[0]+mx[0])/2,(mn[1]+mx[1])/2,(mn[2]+mx[2])/2];
 const conv=p=>{const q=sub(p,ctr);return[dot(q,Fv),dot(q,Lf),dot(q,U)]},cnv=n=>[dot(n,Fv),dot(n,Lf),dot(n,U)];
 let x0=1e9,x1=-1e9;for(const k in groups){const v=groups[k].v;for(let i=0;i<v.length;i+=12){const c=conv([v[i],v[i+1],v[i+2]]);x0=Math.min(x0,c[0]);x1=Math.max(x1,c[0])}}
 let zmin=1e9;for(const k in groups){const v=groups[k].v;for(let i=0;i<v.length;i+=12)zmin=Math.min(zmin,conv([v[i],v[i+1],v[i+2]])[2])}
 const sc=(opt.len||60)/Math.max(1e-6,x1-x0),parts=[];
 for(const k in groups){const g=groups[k],v=g.v,out=new Float32Array(v.length/12*12);let w=0;
  for(let i=0;i<v.length;i+=12){const p=conv([v[i],v[i+1],v[i+2]]),n=cnv([v[i+3],v[i+4],v[i+5]]);out[w++]=p[0]*sc;out[w++]=p[1]*sc;out[w++]=p[2]*sc+(opt.dz||0)-(opt.base?zmin*sc:0);out[w++]=n[0];out[w++]=n[1];out[w++]=n[2];out[w++]=v[i+6];out[w++]=v[i+7];out[w++]=v[i+8];out[w++]=4;out[w++]=v[i+9];out[w++]=v[i+10]}
  let tx=null;if(g.mt.t>=0&&tex[g.mt.t])tx=mktex(tex[g.mt.t],true);parts.push({buf:mkbuf(out),n:out.length/12,tex:tx,blend:g.mt.blend||(g.v[11]<.95?1:0),alpha:g.v[11]})}
 return{parts,L:(x1-x0)*sc,x0:x0*sc,x1:x1*sc,glb:1}}
async function loadGLB(key,opt){if(glbLoading[key])return;glbLoading[key]=1;try{const r=await fetch('models/'+opt.file,{cache:'force-cache'});if(!r.ok)return;const ab=await r.arrayBuffer();const m=await parseGLB(ab,opt);GLB[key]=m;V3.models[key]=m;console.info('[3D] модель загружена:',key,opt.file)}catch(e){console.warn('[3D] не удалось загрузить',key,e&&e.message)}}
const GLEN={tank:42,truck:30,fuel:32,aaa:26,mpad:14,radar:30,sam:40,depot:74,ship:112,bridge:170,bld0:30,bld1:38,bld2:26,carrier:620,airbase:780,hangar:90,tower:16,pilot:8,chute:30};
function defOpt(k,o){o=Object.assign({},o);const ai=AKEYS.indexOf(k);
 if(ai>=0){if(!o.len){const b=ctrBox(PL[ai].sh);o.len=b.L*2.2}}
 else if(MSP[k]){if(!o.len)o.len=MSP[k].L*MSP[k].k*1.5}
 else if(BS[k]){if(!o.len)o.len=BS[k].L}
 else{if(!o.len)o.len=GLEN[k]||40;if(o.base===undefined)o.base=true}
 return o}
async function loadManifest(){try{const r=await fetch('models/manifest.json',{cache:'no-cache'});if(!r.ok)return;const j=await r.json();for(const k in j){if(k[0]=='_')continue;if(!j[k]||!j[k].file)continue;MAN[k]=j[k];loadGLB(k,defOpt(k,j[k]))}}catch(e){}}
V3.loadModel=(key,url,opt)=>{opt=Object.assign({},opt||{},{file:url.replace(/^models\//,'')});MAN[key]=opt;glbLoading[key]=0;return loadGLB(key,defOpt(key,opt))};
V3.manifest=MAN;
/* получить модель: GLB (если есть) иначе процедурную */
function jetModel(d){const key=SHKEY[d.sh];if(GLB[key])return GLB[key];const col=d.col||'#888';return getProc('j'+d.sh+col,()=>d.heli?buildJet(d.sh,col):buildJet(d.sh,col))}
const jetLen=m=>m.glb?m.L:(m.L)*2;
function missModel(id){if(GLB[id])return GLB[id];return getProc('m'+id,()=>buildMissile(id))}
function bombModel(id){if(GLB[id])return GLB[id];return getProc('b'+id,()=>buildBomb(id))}
function gModel(key,fn){const gk=key=='radarB'?'radar':key;if(GLB[gk])return GLB[gk];return getProc('g'+key,fn||GB[key])}
/* ---------- рельеф ---------- */
const smo=(a,b,v)=>{v=(v-a)/(b-a);v=v<0?0:v>1?1:v;return v*v*(3-2*v)};
const mixc=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];
let AFZ=null;
const tz=(x,y)=>{let z=GH(x,y)*ZS;if(AFZ){const d=Math.hypot(x-AFZ.x,y-AFZ.y);z=AFZ.h+(z-AFZ.h)*smo(650,1350,d)}return z};   // высота земли (площадка аэродрома выровнена)
function farCol(x,y,h){let c;
 if(h<WL){const t=cl((WL-h)/.17,0,1);c=mixc(mixc(TP.shal,TP.mid,smo(.04,.42,t)),TP.deep,smo(.36,1,t));const w=nz(x,y,36);const k=1+(w-.5)*.16;c=[c[0]*k,c[1]*k,c[2]*k];if(h>WL-.012)c=mixc(c,TP.foam,.5*(1-(WL-h)/.012))}
 else{c=mixc(TP.gr1,TP.gr2,cl(nz(x,y,70)*.8+nz(x,y,21)*.5-.25,0,1));c=mixc(c,TP.dry,smo(.58,.7,h)*.55);
  const ff=nz(x+900,y-400,520)+(nz(x,y,60)-.5)*.14,fm=smo(.55,.62,ff)*smo(.5,.53,h)*(1-smo(.66,.7,h));if(fm>.02)c=mixc(c,TP.frs,fm);
  const fld=smo(.56,.62,nz(x-300,y+800,950))*smo(.5,.53,h)*(1-smo(.57,.61,h))*(1-fm);if(fld>.02)c=mixc(c,TP.f2,fld*.7);
  const rk=smo(.62,.76,h);if(rk>0)c=mixc(c,TP.rock,rk*.9);const sn=smo(.8,.86,h);if(sn>0)c=mixc(c,TP.snow,sn);
  c=mixc(c,TP.sand,1-smo(WL+.026,WL+.048,h));const k=1+(nz(x,y,7)-.5)*.3;c=[c[0]*k,c[1]*k,c[2]*k]}
 if(TD0===1)c=[c[0]*.17,c[1]*.26,c[2]*.34];return[c[0]/255,c[1]/255,c[2]/255]}
const CHK=new Map();let palKey='',chkBudget=0;
function chunkMesh(ci,cj,N){const key=ci+','+cj+','+N;let c=CHK.get(key);if(c){CHK.delete(key);CHK.set(key,c);return c}
 const x0=ci*CS,y0=cj*CS,st=CS/N,nv=(N+1)*(N+1),v=new Float32Array(nv*9),idx=new Uint16Array(N*N*6);let w=0;
 const bx=ci*CS-CR,by=cj*CS-CR,sz=TM*CR;let hasW=0;
 for(let j=0;j<=N;j++)for(let i=0;i<=N;i++){const x=x0+i*st,y=y0+j*st,h=ht(x,y),z=h<WL?0:tz(x,y);const col=farCol(x,y,h),wt=h<WL?1:0;hasW|=wt;
  v[w++]=x;v[w++]=-y;v[w++]=z;v[w++]=(x-bx)/sz;v[w++]=(y-by)/sz;v[w++]=col[0];v[w++]=col[1];v[w++]=col[2];v[w++]=wt}
 let k=0;for(let j=0;j<N;j++)for(let i=0;i<N;i++){const a=j*(N+1)+i,b=a+1,c2=a+N+1,d=c2+1;idx[k++]=a;idx[k++]=c2;idx[k++]=b;idx[k++]=b;idx[k++]=c2;idx[k++]=d}
 const vb=gl.createBuffer(),ib=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,v,gl.STATIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,idx,gl.STATIC_DRAW);
 c={vb,ib,n:idx.length,ci,cj,N,tex:null,tc:null};CHK.set(key,c);
 if(CHK.size>900){const k0=CHK.keys().next().value,o=CHK.get(k0);gl.deleteBuffer(o.vb);gl.deleteBuffer(o.ib);if(o.tex)gl.deleteTexture(o.tex);CHK.delete(k0)}
 return c}
function clearChunks(){for(const o of CHK.values()){gl.deleteBuffer(o.vb);gl.deleteBuffer(o.ib);if(o.tex)gl.deleteTexture(o.tex)}CHK.clear()}
const TEXR=3;                      // радиус (в чанках) с настоящей текстурой 2D-карты
let texGen=0;
function terrain(cx,cy,fw,P_,eye){
 const afk=AF&&!AF.cv?(AF.x|0)+','+(AF.y|0):'';if(afk!==(AFZ?AFZ.k:'')){AFZ=afk?{x:AF.x,y:AF.y,h:GH(AF.x,AF.y)*ZS,k:afk}:null}
 const key=T.sea+T.land+T.hill+'|'+TD0+'|'+SB+'|'+afk;if(key!==palKey){if(palKey)clearChunks();palKey=key}
 const ci0=Math.floor(cx/CS),cj0=Math.floor(cy/CS),R=12;chkBudget=7;texGen=1;const list=[];
 for(let j=cj0-R;j<=cj0+R;j++)for(let i=ci0-R;i<=ci0+R;i++){const dx=(i+.5)*CS-cx,dy=(j+.5)*CS-cy,d=Math.hypot(dx,dy);if(d>R*CS)continue;
  const fwd=dx*fw[0]+dy*fw[1];if(fwd<-CS*1.5&&d>CS*2.2)continue;list.push([d,i,j])}
 list.sort((a,b)=>a[0]-b[0]);
 gl.useProgram(PGT);gl.uniformMatrix4fv(U(PGT,'uVP'),false,P_.VP);gl.uniform3fv(U(PGT,'uE'),eye);gl.uniform3fv(U(PGT,'uL'),P_.L);gl.uniform3fv(U(PGT,'uFc'),P_.fc);gl.uniform1f(U(PGT,'uFog'),P_.fog);gl.uniform1f(U(PGT,'uSun'),P_.sun);gl.uniform1f(U(PGT,'uNf'),P_.nf);gl.uniform1f(U(PGT,'uT'),P_.t);gl.uniform1i(U(PGT,'uTex'),0);
 const aP=AT(PGT,'aP'),aU=AT(PGT,'aU'),aC=AT(PGT,'aC'),aW=AT(PGT,'aW');gl.enableVertexAttribArray(aP);gl.enableVertexAttribArray(aU);gl.enableVertexAttribArray(aC);gl.enableVertexAttribArray(aW);
 for(const[d,i,j]of list){const rc=Math.max(Math.abs(i-ci0),Math.abs(j-cj0)),N=rc<=3?12:rc<=8?8:5;
  if(chkBudget<=0&&!CHK.has(i+','+j+','+N)){/* нет бюджета: берём любой доступный LOD */let f=null;for(const n2 of[12,8,5]){const q=CHK.get(i+','+j+','+n2);if(q){f=q;break}}if(!f)continue}
  const had=CHK.has(i+','+j+','+N);const ch=chunkMesh(i,j,N);if(!had)chkBudget--;
  let useT=0;
  if(rc<=TEXR){let c=tget(i,j,0);
   if(!c&&texGen>0){c=tget(i,j,1);texGen--}else if(c&&c.sb!==SB&&texGen>0&&c.sb!==undefined){/* устаревшая по времени суток */const c2=tget(i,j,1,1);if(c2)c=c2;texGen--}
   if(c){if(ch.tc!==c){if(ch.tex)gl.deleteTexture(ch.tex);ch.tex=mktex(c,false);ch.tc=c}useT=1}}
  else if(ch.tex){gl.deleteTexture(ch.tex);ch.tex=null;ch.tc=null}
  gl.uniform1f(U(PGT,'uUse'),useT&&ch.tex?1:0);if(useT&&ch.tex){gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,ch.tex)}
  gl.bindBuffer(gl.ARRAY_BUFFER,ch.vb);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ch.ib);
  gl.vertexAttribPointer(aP,3,gl.FLOAT,false,36,0);gl.vertexAttribPointer(aU,2,gl.FLOAT,false,36,12);gl.vertexAttribPointer(aC,3,gl.FLOAT,false,36,20);gl.vertexAttribPointer(aW,1,gl.FLOAT,false,36,32);
  gl.drawElements(gl.TRIANGLES,ch.n,gl.UNSIGNED_SHORT,0)}
 gl.disableVertexAttribArray(aU);gl.disableVertexAttribArray(aW)}
/* ---------- частицы / билборды ---------- */
const PN={a:new Float32Array(9*6*3000),n:0},PD={a:new Float32Array(9*6*3000),n:0};
let CR_=[1,0,0],CU_=[0,0,1],CE_=[0,0,0];
const cuv=i=>{const u=(i%4)*.25,v=((i/4)|0)*.25;return[u+.004,v+.004,u+.246,v+.246]};
function pq(buf,P0,P1,P2,P3,cell,c){if(buf.n+54>buf.a.length)return;const a=buf.a;let o=buf.n;const t=cuv(cell);
 const V=[[P0,t[0],t[1]],[P1,t[2],t[1]],[P2,t[2],t[3]],[P0,t[0],t[1]],[P2,t[2],t[3]],[P3,t[0],t[3]]];
 for(const[p,u,v]of V){a[o++]=p[0];a[o++]=p[1];a[o++]=p[2];a[o++]=u;a[o++]=v;a[o++]=c[0];a[o++]=c[1];a[o++]=c[2];a[o++]=c[3]}buf.n=o}
function bill(buf,x,y,z,s,cell,c,rot){let r=CR_,u=CU_;if(rot){const cs=Math.cos(rot),sn=Math.sin(rot);r=[CR_[0]*cs+CU_[0]*sn,CR_[1]*cs+CU_[1]*sn,CR_[2]*cs+CU_[2]*sn];u=[CU_[0]*cs-CR_[0]*sn,CU_[1]*cs-CR_[1]*sn,CU_[2]*cs-CR_[2]*sn]}
 const rx=r[0]*s,ry=r[1]*s,rz=r[2]*s,ux=u[0]*s,uy=u[1]*s,uz=u[2]*s;
 pq(buf,[x-rx-ux,y-ry-uy,z-rz-uz],[x+rx-ux,y+ry-uy,z+rz-uz],[x+rx+ux,y+ry+uy,z+rz+uz],[x-rx+ux,y-ry+uy,z-rz+uz],cell,c)}
function streak(buf,p0,p1,w,cell,c){const d=sub(p1,p0),m=[(p0[0]+p1[0])/2,(p0[1]+p1[1])/2,(p0[2]+p1[2])/2];let sd=cross(d,sub(CE_,m));const l=Math.hypot(sd[0],sd[1],sd[2])||1;sd=[sd[0]/l*w,sd[1]/l*w,sd[2]/l*w];
 pq(buf,[p0[0]-sd[0],p0[1]-sd[1],p0[2]-sd[2]],[p1[0]-sd[0],p1[1]-sd[1],p1[2]-sd[2]],[p1[0]+sd[0],p1[1]+sd[1],p1[2]+sd[2]],[p0[0]+sd[0],p0[1]+sd[1],p0[2]+sd[2]],cell,c)}
function flat(buf,x,y,z,rx,ry,yaw,cell,c){const cs=Math.cos(yaw),sn=Math.sin(yaw),P=(a,b)=>[x+cs*a*rx-sn*b*ry,y+sn*a*rx+cs*b*ry,z];pq(buf,P(-1,-1),P(1,-1),P(1,1),P(-1,1),cell,c)}
const CCACHE=new Map();
function parseCol(s){let c=CCACHE.get(s);if(c)return c;let m=/rgba?\(([^)]+)\)/.exec(s);if(m){const p=m[1].split(',').map(Number);c=[p[0]/255,p[1]/255,p[2]/255,p.length>3?p[3]:1]}else if(s&&s[0]=='#'){const h=hexc(s);c=[h[0],h[1],h[2],1]}else c=[1,1,1,1];if(CCACHE.size>400)CCACHE.clear();CCACHE.set(s,c);return c}
/* ---------- состояние камеры/кадра ---------- */
const S={dt:.016,t:0,fr:{},last:0,ca:0,eye:[0,0,300],look:[0,0,0],up:[0,0,1],VP:IDM,mode:0,gmcam:null,fov:1};
V3.project=(x,y,z)=>{const v=S.VP,p=[x,-y,z],w=v[3]*p[0]+v[7]*p[1]+v[11]*p[2]+v[15];if(w<=1)return null;const cx=(v[0]*p[0]+v[4]*p[1]+v[8]*p[2]+v[12])/w,cy=(v[1]*p[0]+v[5]*p[1]+v[9]*p[2]+v[13])/w;return{x:(cx*.5+.5)*W,y:(1-(cy*.5+.5))*H,w}};
const gzAt=(x,y)=>{if(AF&&AF.cv){const dx=x-AF.x,dy=y-AF.y,c=Math.cos(AF.a),s=Math.sin(AF.a),lx=dx*c+dy*s,ly=-dx*s+dy*c;if(Math.abs(lx)<300&&Math.abs(ly)<50)return 20}else if(AF&&AF.rw){const dx=x-AF.x,dy=y-AF.y;if(Math.abs(dx)<400&&Math.abs(dy)<150)return tz(x,y)+1}return tz(x,y)};
const altZ=o=>{const g=gzAt(o.x,o.y);if(o.gnd)return g;return Math.max(AL(o)*ZS,g+10)};
/* ---------- рисование моделей ---------- */
let cur=null,blendQ=[];
function setupMeshProg(fr){gl.useProgram(PGM);const p=PGM;gl.uniformMatrix4fv(U(p,'uVP'),false,fr.VP);gl.uniform3fv(U(p,'uE'),fr.eye);gl.uniform3fv(U(p,'uL'),fr.L);gl.uniform3fv(U(p,'uFc'),fr.fc);gl.uniform1f(U(p,'uFog'),fr.fog);gl.uniform1f(U(p,'uSun'),fr.sun);gl.uniform1f(U(p,'uNf'),fr.nf);gl.uniform1i(U(p,'uTex'),0);
 for(const n of['aP','aN','aC','aM','aU'])gl.enableVertexAttribArray(AT(p,n))}
function drawParts(m,M,tint,em,blendPass){const p=PGM;gl.uniformMatrix4fv(U(p,'uM'),false,M);gl.uniform3fv(U(p,'uTint'),tint||[1,1,1]);gl.uniform1f(U(p,'uEm'),em||0);
 let any=0;for(const pt of m.parts){if(!!pt.blend!==!!blendPass){if(pt.blend&&!blendPass)any=1;continue}
  gl.bindBuffer(gl.ARRAY_BUFFER,pt.buf);gl.vertexAttribPointer(AT(p,'aP'),3,gl.FLOAT,false,48,0);gl.vertexAttribPointer(AT(p,'aN'),3,gl.FLOAT,false,48,12);gl.vertexAttribPointer(AT(p,'aC'),3,gl.FLOAT,false,48,24);gl.vertexAttribPointer(AT(p,'aM'),1,gl.FLOAT,false,48,36);gl.vertexAttribPointer(AT(p,'aU'),2,gl.FLOAT,false,48,40);
  gl.uniform1f(U(p,'uUseTex'),pt.tex?1:0);gl.uniform1f(U(p,'uBlend'),blendPass?1:0);gl.uniform1f(U(p,'uAlpha'),blendPass?(pt.alpha==null?.5:pt.alpha):1);if(pt.tex){gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,pt.tex)}
  gl.drawArrays(gl.TRIANGLES,0,pt.n)}
 return any}
function dm(m,M,tint,em){if(!m)return;if(drawParts(m,M,tint,em,0))blendQ.push([m,M,tint,em])}
/* ---------- состояние самолёта (крен/тангаж) ---------- */
function pst(o){let s=o._s3;const al=o.gnd?0:AL(o);if(!s||S.t-s.t>.5){s=o._s3={a:o.a,al,roll:0,pitch:0,t:S.t,rr:0}}
 const dt=Math.max(.001,S.t-s.t);if(dt>0){const rate=wrp(o.a-s.a)/dt,dz=(al-s.al)*ZS/dt,v=Math.max(80,o.v||200);
  const tr=cl(rate*.55,-1.25,1.25),tp=cl(Math.atan2(dz,v),-.6,.6)*1.0;const k=Math.min(1,dt*5);s.roll+=(tr-s.roll)*k;s.pitch+=(tp-s.pitch)*Math.min(1,dt*4);s.a=o.a;s.al=al;s.t=S.t}
 if(o===P&&o.rl!==undefined&&V3.fm()&&!o.gnd){s.roll=o.rl;s.pitch=o.pt||0}
 return s}
/* ---------- самолёты ---------- */
const NIGHTL=(x,y,z,col,c2)=>{bill(PD,x,y,z,c2,0,col)};
function drawPlane(p,isP,hideP){if(p.dead||!p.d||p.d.sh===undefined)return;const d=p.d;if(p.uav)return;
 const m=jetModel(d),s=m.glb?1:2.2,st=pst(p),z=altZ(p)+(p.gnd?(p.gr>.3&&!d.heli?9:3):0);
 let roll=st.roll,pitch=st.pitch;if(p.gnd){roll=0;pitch=0}
 if(p.mv>0){if(p.mk=='b')roll+=(1-p.mv/.9)*12.57;else if(p.mk=='i')pitch+=(1-p.mv/.8)*6.28}
 if(p.dead===0&&p.hp<p.mhp*.25&&!p.gnd){roll+=Math.sin(S.t*3+(p.ph||0))*.35}
 const M=orient(p.x,p.y,z,p.a,pitch,roll,s);
 const hide=hideP;
 if(!hide){dm(m,M,null,0);
  // шасси
  if(p.gr>.04&&!d.heli){const g=GRT[d.sh];if(g&&g[2]){const k=cl(p.gr,0,1),gm=getProc('gear'+d.sh,()=>{BUF=[];YF=1;const wc=[.07,.07,.08];for(const sy of[1,-1]){box(g[1],sy*g[2],-3,3.4,1.6,3.4,wc,3);box(g[1],sy*g[2]*.9,-1.6,.5,.5,3,[.6,.6,.62],4)}box(g[0],0,-3,3,1.4,3,wc,3);box(g[0],0,-1.6,.5,.5,3,[.6,.6,.62],4);return{v:new Float32Array(BUF),L:0}});
   drawParts(gm,mul(M,Sc(1,1,.4+.6*k)),null,0,0)}}
 }
 // тень
 const gh=gzAt(p.x,p.y),hh=Math.max(0,z-gh),L=(m.glb?m.L:(m.L*s));
 if(!hide||true){const a=.34*Math.max(.12,1-hh/1100);flat(PN,p.x,-p.y,gh+1.4,L*(d.heli?.32:.5),L*(d.heli?.26:.42),-p.a,0,[0,0,0,a*(d.heli?.7:1)])}
 return{M,z,st,L,m,s}}
const CLEN={};
function ctrBox(sh){if(CLEN[sh])return CLEN[sh];let a0=1e9,a1=-1e9;for(const q of SH[sh])for(const pp of q[0]){a0=Math.min(a0,pp[0]);a1=Math.max(a1,pp[0])}return CLEN[sh]={xc:(a0+a1)/2,L:a1-a0}}
function lcF(m,d){if(!m.glb)return{f:1,xc:0};const b=ctrBox(d.sh);return{f:m.L/b.L,xc:b.xc}}
function planeFX(p,info,isP){if(!info)return;const{M,z,m,s,L}=info,d=p.d,{f,xc}=lcF(m,d),sd=SD[d.sh]||{};
 if((d.heli||sd.pr)&&!(m.glb&&!(MAN[SHKEY[d.sh]]&&MAN[SHKEY[d.sh]].rotor))){const gs=p.gnd&&(p.v||0)<5&&(p.thr||0)<.1,a=S.t*(gs?7:30);
  if(d.heli){const rt=d.rot,k=d.sh==15||(rt&&rt.co),Rl=(rt?rt.R:(k?24:23))*f,n=rt?rt.n:4,zc=4.6*f,mx=(0-xc)*f;
   const bm=getProc('bl'+n,()=>buildBlades(1,n,[.1,.1,.11]));
   drawParts(bm,mul(M,mul(Tr(mx,0,zc),mul(Rz(a),Sc(Rl,Rl,1)))),null,0,0);
   if(k)drawParts(bm,mul(M,mul(Tr(mx,0,zc-1.6*f),mul(Rz(-a*1.1+.5),Sc(Rl,Rl,1)))),null,0,0);
   const c=xf(M,[mx,0,zc]);flat(PN,c[0],c[1],c[2],Rl*s,Rl*s,0,7,[.14,.14,.16,gs?.08:.16]);
   if(!k||(rt&&rt.tx)){const tx=((rt&&rt.tx)||-35),tl=getProc('tbl',()=>buildBlades(1,4,[.1,.1,.11]));drawParts(tl,mul(M,mul(Tr((tx-xc)*f,2.4*f,1.5*f),mul(Rx(1.5708),mul(Rz(-a*1.8),Sc(3.5*f,3.5*f,1))))),null,0,0)}}
  else{const pm=getProc('prop',()=>buildBlades(1,4,[.1,.1,.11]));for(const[x,y,r]of sd.pr)for(const sy of[1,-1]){const rl=r*f;drawParts(pm,mul(M,mul(Tr((x-xc)*f,Math.abs(y)*sy*f,0),mul(Ry(1.5708),mul(Rz(a*sy),Sc(rl,rl,1))))),null,0,0);
    const c=xf(M,[(x-xc)*f,Math.abs(y)*sy*f,0]);bill(PN,c[0],c[1],c[2],rl*s*.95,7,[.12,.12,.12,.13])}}}
 const ex=sd.ex||[],thv=isP?(p.fu>0?p.thr:0):(p.thr==null?.7:p.thr),fl=(thv<.05?0:3+15*thv)*(p.ab?3.4:1.3)*.62;
 if(fl>0&&!d.heli){const su=d.nat=='su',ab=!!p.ab,C=su?(ab?[.4,.55,1]:[.45,.6,1]):(ab?[1,.55,.15]:[1,.5,.15]),C2=su?[.85,.92,1]:[1,.86,.5];
  for(const[x,y,r]of ex)for(const sy of y?[1,-1]:[1]){const px=(x-xc)*f,py=y*sy*f,fk=.85+.15*Math.sin(S.t*60+x*3+sy)+Math.random()*.1,fo=fl*fk*(ab?1:.8)*f;
   const a=xf(M,[px-.5*f,py,0]),b=xf(M,[px-.5*f-fo,py,0]);streak(PD,a,b,r*s*f*(ab?1.15:.8),2,[C[0],C[1],C[2],ab?.9:.6]);
   const b2=xf(M,[px-.5*f-fo*.55,py,0]);streak(PD,a,b2,r*s*f*.5,2,[C2[0],C2[1],C2[2],.95]);
   bill(PD,a[0],a[1],a[2],r*s*f*3.2,0,[C[0],C[1],C[2],ab?.5:.28])}}
 if(nf>.25&&!d.heli){const al=Math.min(1,nf*1.5),w=wtp(p),sp=Math.abs(w[1]);const l=xf(M,[(w[0]-xc)*f,sp*f,0]),r=xf(M,[(w[0]-xc)*f,-sp*f,0]);bill(PD,l[0],l[1],l[2],5*s,0,[1,.15,.15,.9*al]);bill(PD,r[0],r[1],r[2],5*s,0,[.2,1,.3,.9*al]);if(Math.floor(S.t*1.6+(p.ph||0))%4==0){const t=xf(M,[-L/2/s,0,3]);bill(PD,t[0],t[1],t[2],7*s,0,[1,1,1,al])}}
}
/* ---------- ракеты, бомбы, пули, прочее ---------- */
function estZ(x,y,r){let best=1e9,bz=null;const chk=(o,z)=>{const d=Math.hypot(o.x-x,o.y-y);if(d<best&&d<(r||80)){best=d;bz=z}};
 for(const e of E)if(!e.dead)chk(e,altZ(e));for(const e of A)if(!e.dead)chk(e,altZ(e));if(P&&!P.dead)chk(P,altZ(P));
 for(const m of M)chk(m,Math.max((m.al==null?.5:m.al)*ZS,gzAt(m.x,m.y)+5));return bz}
function drawMissiles(){for(const m of M){const w=WC[m.id];if(!w)continue;const g0=gzAt(m.x,m.y),z=Math.max((m.al==null?.5:m.al)*ZS,g0+6);
  let s=m._s3;if(!s||S.t-s.t>.5)s=m._s3={z,t:S.t,p:0};const dt=Math.max(.001,S.t-s.t);if(dt>.0005){const tp=cl(Math.atan2((z-s.z)/dt,Math.max(100,m.v||500)),-1.2,1.2);s.p+=(tp-s.p)*Math.min(1,dt*8);s.z=z;s.t=S.t}
  const mod=missModel(m.id),sc=(mod.glb?1:1.5)*(m.vt>0?.45+.55*(1-m.vt/(m.vt0||.8)):1)*(m.fl2?.55+.45*(m.fl2/1.1):1);
  const wob=(m.wb||0)*.16*Math.sin(S.t*44+m.u)+.02*Math.sin(S.t*23+m.u*3),M_=orient(m.x,m.y,z,m.a+wob,s.p,S.t*6*(m.u%2?1:-1),mod.glb?sc:sc);
  dm(mod,M_,null,0);
  const bn=m.age<w.burn&&!m.fl2,tail=xf(M_,[mod.x0||-20,0,0]);
  if(bn){const msp=MSP[m.id]||MSP.sam,ex=(msp.ex||.5),len=(10+Math.random()*12)*ex*1.7*(w.big?1.4:1),back=xf(M_,[(mod.x0||-20)-len/sc*1.0,0,0]);
   streak(PD,tail,back,3.2*(w.big?1.4:1),2,[1,.62,.22,.95]);streak(PD,tail,xf(M_,[(mod.x0||-20)-len*.5/sc,0,0]),1.6,2,[1,.95,.8,1]);bill(PD,tail[0],tail[1],tail[2],20*(w.big?1.4:1),0,[1,.66,.28,.8])}
  if(m.tg===P&&!P.dead&&((S.t*8)|0)%2)bill(PD,M_[12],M_[13],M_[14],22,0,[1,.15,.1,.55]);
  // тень
  flat(PN,m.x,-m.y,g0+1.4,10,4,-m.a,0,[0,0,0,.22*Math.max(.1,1-(z-g0)/1000)])}}
function drawBombs(){for(const b of BM){if(b._z0==null){const ez=estZ(b.x,b.y,120);b._z0=ez!=null?ez:Math.max(80,(b.t-1.5)/2.6*ZS);b._t0=Math.max(b.t,.3)}
  const u=cl(b.t/b._t0,0,1),g0=gzAt(b.x,b.y),z=g0+3+(b._z0-g0)*u*u,an=Math.atan2(b.vy,b.vx),pitch=-(1-u)*1.1,mod=bombModel(b.id),sc=mod.glb?1:1.0;
  dm(mod,orient(b.x,b.y,z,an,pitch,0,sc),null,0);flat(PN,b.x,-b.y,g0+1.4,8,4,-an,0,[0,0,0,.25*u])}}
function drawBullets(){for(const b of B){if(b._z==null){const ez=estZ(b.x,b.y,70);b._z=ez!=null?ez:(b.al!=null?b.al*ZS:gzAt(b.x,b.y)+16)}
  const z=b._z,p1=[b.x,-b.y,z],p0=[b.x-b.vx*.04,-(b.y-b.vy*.04),z];const c=b.team?[1,.45,.45]:b.ga==1?[.6,.85,1]:b.ga==2?[1,.6,.25]:[1,.88,.4];
  streak(PD,p0,p1,1.4,6,[c[0],c[1],c[2],1]);bill(PD,b.x,-b.y,z,6,0,[c[0],c[1],c[2],.6])}}
function drawFlares(){for(const f of F){if(f._z==null){const ez=estZ(f.x,f.y,90);f._z=ez!=null?ez:gzAt(f.x,f.y)+30;f._t=S.t}const z=f._z-(S.t-f._t)*35;
  if(f.k=='c')bill(PN,f.x,-f.y,z,14,2,[.8,.84,.88,Math.min(1,f.l)*.45]);else{bill(PD,f.x,-f.y,z,22,0,[1,.85,.4,Math.min(1,f.l)*.9]);bill(PD,f.x,-f.y,z,7,2,[1,1,.9,1])}}}
function drawFX(){let n=0;for(const f of FX){if(f.l<=0||n>1100)continue;const dx=f.x-S.cx,dy=f.y-S.cy;if(dx*dx+dy*dy>1.6e8)continue;
  if(f._z==null){const ez=estZ(f.x,f.y,Math.max(40,f.r||10));f._z=ez!=null?ez:gzAt(f.x,f.y)+(f.r||8)*.4;f._t=S.t}
  const z=f._z+(f.sp&&!f.m?(S.t-f._t)*6:0),col=parseCol(f.c||'#fff');n++;
  if(f.ring){const a=Math.min(1,f.l*1.6)*col[3];flat(PD,f.x,-f.y,z,f.r,f.r,0,4,[col[0],col[1],col[2],a*.9]);continue}
  if(f.sk){const p1=[f.x,-f.y,z],p0=[f.x-f.vx*.05,-(f.y-f.vy*.05),z];streak(PD,p0,p1,Math.max(.8,f.r*.5),6,[col[0],col[1],col[2],Math.min(1,f.l*1.7)]);continue}
  if(f.m){const a=Math.min(1,f.l*1.7)*(f.sp?1:col[3]),r=f.sp?f.r*1.2:f.r*1.6+1.5;bill(PD,f.x,-f.y,z,r*1.1,f.sp?2:0,[col[0],col[1],col[2],a],f.rot||0)}
  else{const a=Math.max(0,Math.min(1,f.l*1.2))*(f.sp?.7:1)*col[3];bill(PN,f.x,-f.y,z,f.r*1.15*1.3,f.sp?1:2,[col[0],col[1],col[2],f.sp?Math.min(1,a*1.6):a],f.rot||0)}}}
function drawPK(){for(const k of PK){const g0=gzAt(k.x,k.y),z=g0+22+Math.sin(S.t*2+k.x)*4,c=k.k=='h'?[.12,.55,.3]:k.k=='f'?[.23,.51,.77]:[.85,.28,.06];
  dm(gModel('pk'),orient(k.x,k.y,z,S.t*1.2,.35,0,1),c,0);bill(PD,k.x,-k.y,z,40,0,[c[0],c[1],c[2],.35])}}
function drawPJ(){for(const j of PJ){const g0=gzAt(j.x,j.y),z=j.al!=null?Math.max(g0+10,j.al*ZS):g0+50;dm(gModel('chute'),orient(j.x,j.y,z+34,0,0,0,1),null,0);dm(gModel('pilot'),orient(j.x,j.y,z,0,0,0,1.2),null,0)}}
/* ---------- наземные объекты ---------- */
const GSC={tank:1,truck:1,fuel:1,aaa:1,mpad:1,radar:1,sam:1,depot:1,ship:1.02,bld0:1,pilot:1.5};
function drawGround(){if(!P)return;
 for(const g of G){if(g.dead)continue;const dx=g.x-S.cx,dy=g.y-S.cy;if(dx*dx+dy*dy>8.5e7)continue;const g0=gzAt(g.x,g.y),ty=g.ty;
  const toP=P&&!P.dead?Math.atan2(-(P.y-g.y),P.x-g.x):-g.a,dP=P?Math.hypot(P.x-g.x,P.y-g.y):1e9,pz=P?altZ(P):0;
  if(ty=='tank'){const M0=orient(g.x,g.y,g0,g.a,0,0,1);dm(gModel('tank'),M0,null,0);const rel=dP<3200?wrp(toP-(-g.a)):0;if(!GLB.tank)dm(gModel('tankT'),mul(M0,mul(Tr(-4,0,13),Rz(rel))),null,0)}
  else if(ty=='truck')dm(gModel('truck'),orient(g.x,g.y,g0,g.a,0,0,1),null,0);
  else if(ty=='fuel')dm(gModel('fuel'),orient(g.x,g.y,g0,g.a,0,0,1),null,0);
  else if(ty=='aaa'){const M0=orient(g.x,g.y,g0,g.a,0,0,1);dm(gModel('aaa'),M0,null,0);const rel=dP<4500?wrp(toP-(-g.a)):S.t*.8+(g.ph||0),el=dP<4500?cl(Math.atan2(pz-g0-10,dP),0,1.4):.3;if(!GLB.aaa)dm(gModel('aaaT'),mul(M0,mul(Tr(0,0,3),mul(Rz(rel),Ry(-el)))),null,0)}
  else if(ty=='mpad'){const M0=orient(g.x,g.y,g0,g.a,0,0,1);dm(gModel('mpad'),M0,null,0);const rel=dP<5000?wrp(toP-(-g.a)):0,el=dP<5000?cl(Math.atan2(pz-g0,dP),.2,1.4):.5;if(!GLB.mpad)dm(gModel('mpadT'),mul(M0,mul(Tr(0,0,6),mul(Rz(rel),Ry(-el)))),null,0)}
  else if(ty=='radar'){const M0=orient(g.x,g.y,g0,g.a,0,0,1);dm(gModel('radarB'),M0,null,0);if(!GLB.radar)dm(gModel('radarD'),mul(M0,mul(Tr(0,0,24),mul(Rz(S.t*1.1+(g.ph||0)),Ry(-.35)))),null,0)}
  else if(ty=='sam'){const M0=orient(g.x,g.y,g0,g.a,0,0,1);dm(gModel('sam'),M0,null,0);const act=dP<7000,rel=act?wrp(toP-(-g.a)):0,el=act?1.0:.2;if(!GLB.sam)dm(gModel('samT'),mul(M0,mul(Tr(2,0,8),mul(Rz(rel),Ry(-el)))),null,0)}
  else if(ty=='depot')dm(gModel('depot'),orient(g.x,g.y,g0,g.a,0,0,1),null,0);
  else if(ty=='ship'){const M0=orient(g.x,g.y,0,g.a,Math.sin(S.t*.8+(g.ph||0))*.012,Math.sin(S.t*.6+(g.ph||0))*.02,1);dm(gModel('ship'),M0,null,0)}
  else if(ty=='bridge')dm(gModel('bridge',()=>GB.bridge(g.len||170)),orient(g.x,g.y,g0,g.a,0,0,1),null,0);
  else if(ty=='bld')dm(gModel('bld'+((g.v|0)%3)),mul(orient(g.x,g.y,g0,g.a,0,0,1),Sc(1,1,.7+(g.hh||.7)*.6)),null,0);
  else if(ty=='pilot')dm(gModel('pilot'),orient(g.x,g.y,g0,g.a,0,0,1.5),null,0);
  else if(ty=='jet'&&g.pd){dm(jetModel(g.pd),orient(g.x,g.y,g0+8,g.a,0,0,jetModel(g.pd).glb?1:2.2),null,0)}
  else if(ty=='phel'&&g.pd){dm(jetModel(g.pd),orient(g.x,g.y,g0+4,g.a,0,0,jetModel(g.pd).glb?1:2.2),null,0)}
  else if(g.air){const d={sh:20,col:'#8a4b4b',heli:1,nat:'su'},mo=jetModel(d),s=mo.glb?1:2.2,z=Math.max(g0+30,AL(g)*ZS),st=pst(g);const M0=orient(g.x,g.y,z,g.a,st.pitch*.6,st.roll*.8,s);dm(mo,M0,[1.1,.7,.7],0);planeFX({x:g.x,y:g.y,a:g.a,d,gnd:0,v:g.v,thr:.7,ph:g.ph},{M:M0,z,m:mo,s,L:mo.glb?mo.L:mo.L*s},0);flat(PN,g.x,-g.y,g0+1.4,30,20,-g.a,0,[0,0,0,.25])}
  if(g.hp<g.mhp*.5&&!g.air&&ty!='pilot'&&ty!='ship')bill(PN,g.x,-g.y,g0+20+Math.sin(S.t*3+g.x)*3,20,1,[.12,.12,.12,.3])}
 // скорчи и обломки
 for(const s of SC){const dx=s.x-S.cx,dy=s.y-S.cy;if(dx*dx+dy*dy>6e7)continue;flat(PN,s.x,-s.y,gzAt(s.x,s.y)+1.2,s.r,s.r*.82,-(s.a||0),0,[.03,.025,.02,.62])}
 for(const w of WR){const dx=w.x-S.cx,dy=w.y-S.cy;if(dx*dx+dy*dy>6e7)continue;flat(PN,w.x,-w.y,gzAt(w.x,w.y)+1.3,w.r*1.5,w.r*1.3,-(w.a||0),0,[.03,.025,.02,.7])}
 // база
 if(AF){const g0=AF.cv?0:tz(AF.x,AF.y)+1;if(AF.cv){dm(gModel('carrier'),orient(AF.x,AF.y,0,AF.a,Math.sin(S.t*.5)*.002,Math.sin(S.t*.7)*.004,1),null,0)}
  else{const M0=orient(AF.x,AF.y,g0,AF.a,0,0,1);dm(gModel('airbase'),M0,null,0);for(const dx of[-110,60])dm(gModel('hangar'),mul(M0,Tr(dx,-120,0)),null,0);dm(gModel('tower'),mul(M0,Tr(-170,-70,0)),null,0)}}
 for(const r of RWY){flat(PN,r.x,-r.y,gzAt(r.x,r.y)+1,r.l/2,r.w/2,-r.a,3,[.2,.21,.23,1])}}
/* ---------- облака ---------- */
function drawClouds(){const cd=S.t*9,cdy=S.t*4,R=7000,c0=Math.floor((S.cx-cd-R)/800),c1=Math.floor((S.cx-cd+R)/800),r0=Math.floor((S.cy-cdy-R)/800),r1=Math.floor((S.cy-cdy+R)/800),cb=nf>.5?[.5,.6,.78]:[1,1,1],a0=.62-.35*nf;
 for(let j=r0;j<=r1;j++)for(let i=c0;i<=c1;i++){const h=hs(i+9,j+4);if(h<=.5)continue;const cx=i*800+h*600+cd,cy=j*800+hs(j,i)*600+cdy,rw=(180*h+60)*1.9,zc=1250+hs(i,j+3)*300;
  for(let k=0;k<5;k++){const a=hs(i*7+k,j)*6.28,d=hs(j,i*7+k)*rw*.8;bill(PN,cx+Math.cos(a)*d,-(cy+Math.sin(a)*d*.7),zc+hs(k,i+j)*60,rw*(.45+hs(k,i+j)*.4),5,[cb[0],cb[1],cb[2],a0])}}}
/* ---------- метка бомбового прицела ---------- */
function drawAim(){if(!P||P.dead)return;const w=WC[ws];if(w&&w.t=='b'){const d=P.v*(1.5+2.6*P.al),x=P.x+Math.cos(P.a)*d,y=P.y+Math.sin(P.a)*d;flat(PD,x,-y,gzAt(x,y)+2,w.rad,w.rad,0,4,[1,.7,.2,.9])}}
/* ---------- камера ---------- */
function camSetup(dt){const ref=P,gm=P.gm&&M.includes(P.gm)&&gd&&!P.gm.gl?P.gm:null;let eye,look,up=[0,0,1],fov=.98;
 const dyP=state=='dying'?(PJ.find(j=>j.pl)||null):null;
 const mod=jetModel(P.d),s=mod.glb?1:2.2,len=mod.glb?mod.L:mod.L*s,pz=altZ(P)+(P.gnd?(P.gr>.3&&!P.d.heli?9:3):0),st=pst(P);
 const px=dyP?dyP.x:P.x,py=dyP?dyP.y:P.y,pzz=dyP?Math.max(gzAt(px,py)+20,(dyP.al!=null?dyP.al*ZS:gzAt(px,py)+60)):pz;
 S.mode=gm?4:dyP?3:COCK?2:CINE?3:1;
 if(S.mode==1){S.ca+=wrp(P.a-S.ca)*Math.min(1,dt*3.2);const dist=len*1.9+45,ca=S.ca;
  S.zc+=(pzz-S.zc)*Math.min(1,dt*7);const ex=px-Math.cos(ca)*dist,ey=py-Math.sin(ca)*dist;
  eye=[ex,-ey,Math.max(S.zc+dist*.2+12,gzAt(ex,ey)+14)];look=[px+Math.cos(P.a)*dist*.9,-(py+Math.sin(P.a)*dist*.9),pzz+dist*.04+st.pitch*dist*.5];
  fov=.95+.14*cl((P.v||0)/((P.d.sp||500)*1.1),0,1.2);
  const f=nrm(sub(look,eye)),rt=nrm(cross(f,[0,0,1])),u0=cross(rt,f),r=.22*st.roll;up=nrm([u0[0]*Math.cos(r)+rt[0]*Math.sin(r),u0[1]*Math.cos(r)+rt[1]*Math.sin(r),u0[2]*Math.cos(r)+rt[2]*Math.sin(r)])}
 else if(S.mode==2){S.ca=P.a;const M=orient(P.x,P.y,pz,P.a,st.pitch,P.gnd?0:st.roll,mod.glb?1:s),sdp=(SD[P.d.sh]||{}).cp,lc=lcF(mod,P.d);const loc=sdp?[(sdp[0]-lc.xc)*lc.f+1*lc.f,0,2.6*lc.f]:[len*.1/s,0,2.5];eye=xf(M,loc);look=xf(M,[loc[0]+60,0,loc[2]+3]);up=nrm([M[8],M[9],M[10]]);fov=1.1}
 else if(S.mode==3){const ang=S.t*.35,d=len*3.2+90;eye=[px+Math.cos(ang)*d,-py+Math.sin(ang)*d,Math.max(pzz+d*.2+10,gzAt(px,py)+20)];look=[px,-py,pzz];S.ca=P.a;fov=.8}
 else{S.ca=gm.a;const d=70,ex=gm.x-Math.cos(gm.a)*d,ey=gm.y-Math.sin(gm.a)*d,gz0=Math.max((gm.al==null?.5:gm.al)*ZS,gzAt(gm.x,gm.y)+6);eye=[ex,-ey,gz0+18];look=[gm.x+Math.cos(gm.a)*200,-(gm.y+Math.sin(gm.a)*200),gz0];fov=1.0}
 if(shake>.3){const k=Math.min(shake,12)*.7;eye=[eye[0]+(Math.random()-.5)*k,eye[1]+(Math.random()-.5)*k,eye[2]+(Math.random()-.5)*k]}
 S.eye=eye;S.look=look;S.up=up;S.fov=fov;S.cx=eye[0];S.cy=-eye[1];
 V3.so=Math.atan2(-(look[1]-eye[1]),look[0]-eye[0])+Math.PI/2;V3.cam.x=S.cx;V3.cam.y=S.cy;V3.cam.z=eye[2]}

/* ---------- пилотирование: крен/тангаж/энергия (только игрок, только 3D) ---------- */
V3.inv=false;try{V3.inv=localStorage.getItem('vr_inv')=='1'}catch(e){}
V3.fm=()=>!!(V3.on&&V3.ok&&typeof P!='undefined'&&P&&P.d&&!P.dead&&state=='play');
V3.flight=function(p,tn,dt,st,K,AUP,ADN){
 const d=p.d,hel=!!p.hel,big=(d.sh>=17&&d.sh<=19)||d.sh==30;let rc=tn,pc=0;
 if(st){const m=Math.hypot(st.dx,st.dy);if(m>10){const k=cl((m-10)/60,0,1);rc=cl(st.dx/m*Math.pow(k,1.25),-1,1);pc=cl(-st.dy/m*Math.pow(k,1.25),-1,1)}}
 const ku=K.ArrowUp||K.PageUp||K.Equal||K.BracketRight||AUP,kd=K.ArrowDown||K.PageDown||K.Minus||K.BracketLeft||ADN;if(ku&&!kd)pc=1;else if(kd&&!ku)pc=-1;
 if(V3.inv)pc=-pc;
 p._dal=0;
 if(p.gnd){p.rl=0;p.pt=0;p._wasG=1;p._rotT=0;return rc}
 if(p._wasG){p._wasG=0;p.pt=.1;p._rotT=2.2;if(!V3._hint){V3._hint=1;if(typeof toast=='function')toast('Стик вверх — набор высоты, вниз — снижение, вбок — крен и поворот')}}
 p.rl=p.rl||0;p.pt=p.pt||0;
 const mb=hel?.5:big?.8:1.25,rr=hel?2:big?1.2:2.4+Math.min(1.4,(d.tr||1.5)*.55),pr=hel?1.5:big?1:2.1;
 p.rl+=(rc*mb-p.rl)*Math.min(1,dt*rr);
 if(hel){p.pt+=(pc*.15-p.pt)*Math.min(1,dt*2);p._dal=pc*.32*dt}
 else{let tp=pc>0?pc*.95:pc*.85;if(p._rotT>0){p._rotT-=dt;if(Math.abs(pc)<.1)tp=.16}
  if(p.stl>.05)tp=Math.min(tp,-p.stl*.9);
  const ceil=typeof ceilOf=='function'?ceilOf(p):1;if(p.al>=ceil-.004&&tp>0)tp=0;
  p.pt+=(tp-p.pt)*Math.min(1,dt*pr);if(p.al<=.004&&p.pt<0)p.pt=0;
  const sp=Math.sin(p.pt);p._dal=sp*(p.v||0)/ZS*dt;
  p.v-=sp*200*dt;p.v-=rc*rc*Math.abs(p.rl)*14*dt;p.v=Math.min(p.v,d.sp*1.55)}
 return Math.sin(p.rl)/Math.sin(mb)*(1-.28*Math.abs(p.pt))};
/* ---------- кадр ---------- */
S.zc=0;S.cx=0;S.cy=0;
const HZD=[.72,.84,.95],ZND=[.14,.38,.75],HZN=[.045,.06,.09],ZNN=[.01,.02,.05];
let pbuf=null;
function flushParticles(buf,add,par){if(!buf.n)return;if(!pbuf)pbuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,pbuf);gl.bufferData(gl.ARRAY_BUFFER,buf.a.subarray(0,buf.n),gl.DYNAMIC_DRAW);
 const p=PGP;gl.uniform1f(U(p,'uAdd'),add?1:0);gl.blendFunc(add?gl.ONE:gl.SRC_ALPHA,add?gl.ONE:gl.ONE_MINUS_SRC_ALPHA);
 gl.vertexAttribPointer(AT(p,'aP'),3,gl.FLOAT,false,36,0);gl.vertexAttribPointer(AT(p,'aU'),2,gl.FLOAT,false,36,12);gl.vertexAttribPointer(AT(p,'aC'),4,gl.FLOAT,false,36,20);gl.drawArrays(gl.TRIANGLES,0,buf.n/9)}
V3.frame=function(){if(!gl||!P||!V3.on)return;
 const now=performance.now();let dt=Math.min(.05,(now-S.last)/1000||.016);S.last=now;S.t+=dt;S.dt=dt;
 const r=Math.min(devicePixelRatio||1,1.5),w=Math.max(2,Math.floor(cv3.clientWidth*r)),h=Math.max(2,Math.floor(cv3.clientHeight*r));if(cv3.width!=w||cv3.height!=h){cv3.width=w;cv3.height=h}gl.viewport(0,0,w,h);
 camSetup(dt);const eye=S.eye,asp=w/h;S.VP=mul(persp(S.fov,asp,3,40000),look(eye,S.look,S.up));
 const f=nrm(sub(S.look,eye)),rt=nrm(cross(f,S.up)),upv=cross(rt,f);CR_=rt;CU_=upv;CE_=eye;
 // свет, небо, туман
 const sv=sunv(),dayK=smo(-.12,.3,sv),sun=cl(.3+.7*dayK,.3,1)*(wx?.82:1);let az=(tod-.25)*6.2832,el=Math.asin(cl(sv,-1,1));let L;
 if(sv>-.05){L=nrm([Math.cos(az)*Math.cos(Math.max(el,.12)),Math.sin(az)*Math.cos(Math.max(el,.12))*.6-.2,Math.max(Math.sin(el),.12)])}else L=nrm([.3,-.4,.7]);
 let hz=mixc(HZN,HZD,dayK),ze=mixc(ZNN,ZND,dayK);const dusk=(1-Math.min(1,Math.abs(sv)/.28))*(1-nf);if(dusk>0){hz=mixc(hz,[1,.62,.38],dusk*.65);ze=mixc(ze,[.3,.36,.6],dusk*.4)}
 if(wx){hz=mixc(hz,[.58,.62,.66],.6*dayK+.2);ze=mixc(ze,[.4,.45,.52],.6*dayK)}
 const fog=.0002*(wx?2.4:1),PAR={VP:S.VP,L,fc:hz,fog,sun,nf,t:S.t,eye};
 gl.clearColor(hz[0],hz[1],hz[2],1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);gl.depthMask(true);
 gl.useProgram(PGS);if(!V3._qb){V3._qb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,V3._qb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,1,1,-1,-1,1,1,-1,1]),gl.STATIC_DRAW)}gl.bindBuffer(gl.ARRAY_BUFFER,V3._qb);{const a=AT(PGS,'aP');gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0)}
 const ty=Math.tan(S.fov/2);gl.uniform3fv(U(PGS,'uF'),f);gl.uniform3fv(U(PGS,'uR'),rt);gl.uniform3fv(U(PGS,'uUp'),upv);gl.uniform3fv(U(PGS,'uL'),L);gl.uniform3fv(U(PGS,'uHz'),hz);gl.uniform3fv(U(PGS,'uZe'),ze);gl.uniform2f(U(PGS,'uT'),ty*asp,ty);gl.uniform1f(U(PGS,'uNf'),nf);gl.drawArrays(gl.TRIANGLES,0,6);
 gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);
 // рельеф
 terrain(S.cx,S.cy,[f[0],-f[1]],PAR,eye);
 // модели
 PN.n=0;PD.n=0;blendQ=[];setupMeshProg(PAR);
 drawGround();
 const infos=[];for(const e of E)if(!e.dead)infos.push([e,drawPlane(e,0,0)]);for(const a of A)if(!a.dead)infos.push([a,drawPlane(a,0,0)]);
 if(!P.dead)infos.push([P,drawPlane(P,1,S.mode==2)]);
 drawMissiles();drawBombs();drawPK();drawPJ();
 gl.disableVertexAttribArray(AT(PGM,'aU'));gl.enableVertexAttribArray(AT(PGM,'aU'));
 for(const[o,inf]of infos)planeFX(o,inf,o===P);
 // прозрачные части моделей
 if(blendQ.length){gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);for(const q of blendQ)drawParts(q[0],q[1],q[2],q[3],1);gl.depthMask(true);gl.disable(gl.BLEND)}
 drawClouds();drawBullets();drawFlares();drawFX();drawAim();
 // частицы
 gl.useProgram(PGP);gl.enable(gl.BLEND);gl.depthMask(false);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,ATL);gl.uniform1i(U(PGP,'uTex'),0);gl.uniformMatrix4fv(U(PGP,'uVP'),false,S.VP);gl.uniform1f(U(PGP,'uFog'),fog);gl.uniform3fv(U(PGP,'uFc'),hz);
 for(const n of['aP','aU','aC'])gl.enableVertexAttribArray(AT(PGP,n));
 flushParticles(PN,0);flushParticles(PD,1);
 gl.depthMask(true);gl.disable(gl.BLEND)};
/* ---------- HUD поверх 3D (рисуется в 2D-канвасе игры) ---------- */
const rawP=(x,y,z)=>{const v=S.VP,p=[x,-y,z],w=v[3]*p[0]+v[7]*p[1]+v[11]*p[2]+v[15];let cx=(v[0]*p[0]+v[4]*p[1]+v[8]*p[2]+v[12])/(w||1e-6),cy=(v[1]*p[0]+v[5]*p[1]+v[9]*p[2]+v[13])/(w||1e-6);if(w<=0){cx=-cx;cy=-cy}return{cx,cy,w}};
const pxSize=(r,d)=>Math.max(14,Math.min(140,r*H/(2*Math.tan(S.fov/2)*Math.max(50,d))));
V3.labels=function(){if(!P||!V3.on)return;X.save();
 for(const e of E){if(e.dead)continue;const d=Math.hypot(e.x-S.cx,e.y-S.cy);if(d>8500)continue;const p=V3.project(e.x,e.y,altZ(e)+36);if(!p||p.x<-60||p.x>W+60||p.y<-40||p.y>H+40)continue;
  const k=cl(1.15-d/9000,.45,1),bw=64*k;X.fillStyle='rgba(0,0,0,.45)';X.fillRect(p.x-bw/2,p.y-3,bw,5);X.fillStyle=e.bm?'#ffb020':'#d9534f';X.fillRect(p.x-bw/2,p.y-3,bw*Math.max(0,e.hp)/e.mhp,5);
  X.font='800 '+Math.round(11+3*k)+'px Bahnschrift,"Arial Narrow",sans-serif';X.textAlign='center';
  if(e.jm){X.fillStyle='#8fd6ff';X.fillText('РЭБ',p.x,p.y-8)}if(e.d&&e.d.ace){X.fillStyle='#ff6a5a';X.fillText('АС «'+e.d.ace+'»',p.x,p.y-(e.jm?20:8))}}
 if(!P.dead&&state=='play'&&S.mode!=2){const pt=P.pt||0,cp=Math.cos(pt),rp=V3.project(P.x+Math.cos(P.a)*900*cp,P.y+Math.sin(P.a)*900*cp,altZ(P)+Math.sin(pt)*900);if(rp){if(V3.fm()&&!P.gnd){X.fillStyle='rgba(255,255,255,.7)';X.font='700 11px Bahnschrift,"Arial Narrow",sans-serif';X.textAlign='center';X.fillText('ТАНГ '+Math.round(pt*57.3)+'°  КРЕН '+Math.round((P.rl||0)*57.3)+'°',rp.x,rp.y+28)}X.strokeStyle='rgba(255,255,255,.55)';X.lineWidth=1.6;X.beginPath();X.arc(rp.x,rp.y,9,0,6.3);X.moveTo(rp.x-16,rp.y);X.lineTo(rp.x-9,rp.y);X.moveTo(rp.x+9,rp.y);X.lineTo(rp.x+16,rp.y);X.moveTo(rp.x,rp.y-16);X.lineTo(rp.x,rp.y-9);X.stroke()}}
 if(P.lock&&!P.dead){const l=P.lock,z=(l.g&&!l.air)?gzAt(l.x,l.y)+10:altZ(l),p=V3.project(l.x,l.y,z);if(p){const d=Math.hypot(l.x-S.cx,l.y-S.cy),q=pxSize((l.r||30)+14,d)*(1+.06*Math.sin(S.t*9)),L2=q*.45;X.strokeStyle=T.ac;X.lineWidth=3;X.save();X.translate(p.x,p.y);X.beginPath();for(const[sx,sy]of[[1,1],[1,-1],[-1,1],[-1,-1]]){X.moveTo(sx*q,sy*(q-L2));X.lineTo(sx*q,sy*q);X.lineTo(sx*(q-L2),sy*q)}X.stroke();X.restore()}}
 X.restore()};
V3.arrows=function(){if(!P)return;const L=[...E,...G,...(AF&&(P.fu<40||P.hp<P.mhp*.4||P.gam<100||mis==3)?[AF]:[])];
 for(const e of L){if(e.dead||((e.air||!e.ty)&&!rvis(e))||(e.g&&!e.tgt&&Math.hypot(e.x-P.x,e.y-P.y)>5000))continue;
  const z=(e.g&&!e.air)||e.ty=='af'?gzAt(e.x,e.y)+10:altZ(e),q=rawP(e.x,e.y,z),dx=q.cx*W/2,dy=-q.cy*H/2;if(q.w>0&&Math.abs(dx)<W/2-20&&Math.abs(dy)<H/2-20)continue;
  const k=Math.min((W/2-24)/Math.abs(dx||1),(H/2-24)/Math.abs(dy||1)),a=Math.atan2(dy,dx);X.save();X.translate(W/2+dx*k,H/2+dy*k);X.rotate(a);X.fillStyle=CM[ct(e)];X.beginPath();X.moveTo(10,0);X.lineTo(-8,-8);X.lineTo(-8,8);X.fill();X.restore()}};
/* ---------- включение / кнопка ---------- */
V3.set=function(on){if(on&&!V3.ok){if(typeof toast=='function')toast('3D недоступно: нет WebGL');on=false}V3.on=!!on;try{localStorage.setItem('vr_3d',on?'1':'0')}catch(e){}
 if(cv3)cv3.style.display=on?'block':'none';document.body.classList.toggle('v3on',on);const bi2=$('b3i');if(bi2)bi2.style.display=on?'':'none';const b=$('b3d');if(b){b.textContent=on?'3D → 2D':'2D → 3D';b.style.borderColor=on?'#f0a31c':'#3a444b'}
 if(on){S.last=performance.now();S.ca=P?P.a:0;S.zc=P?altZ(P):0;if(typeof toast=='function'&&P&&state=='play')toast('3D-режим (Y — переключить). Вид: «Кабина», «Кино»')}};
V3.init=function(){if(!initGL()){V3.ok=false;return false}try{initProgs();mkAtlas();initKeys();V3.ok=true}catch(e){console.error('[3D]',e);V3.ok=false;return false}
 cv3.addEventListener('webglcontextlost',e=>{e.preventDefault();V3.ok=false;V3.set(false)});
 loadManifest();
 const stl=document.createElement('style');stl.textContent='body.v3on #bu,body.v3on #bn{display:none!important}';document.head.appendChild(stl);
 const xb=$('xb');if(xb){const bi=document.createElement('button');bi.id='b3i';bi.style.cssText='font:800 11px Bahnschrift,"Arial Narrow",sans-serif;letter-spacing:.08em;color:#d8dde0;background:rgba(14,17,19,.78);border:0;border-left:3px solid #3a444b;padding:7px 9px;cursor:pointer';const ub=()=>{bi.textContent=V3.inv?'Тангаж: вниз=вверх':'Тангаж: вверх=вверх'};ub();bi.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();V3.inv=!V3.inv;try{localStorage.setItem('vr_inv',V3.inv?'1':'0')}catch(x){}ub();if(typeof toast=='function')toast(V3.inv?'Стик вниз — нос вверх (как в авиасимуляторе)':'Стик вверх — нос вверх')});xb.insertBefore(bi,xb.firstChild);const b=document.createElement('button');b.id='b3d';b.style.cssText='font:800 11px Bahnschrift,"Arial Narrow",sans-serif;letter-spacing:.08em;color:#d8dde0;background:rgba(14,17,19,.78);border:0;border-left:3px solid #3a444b;padding:7px 9px;cursor:pointer';b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();V3.set(!V3.on)});xb.insertBefore(b,xb.firstChild)}
 addEventListener('keydown',e=>{if(e.code=='KeyY'&&state=='play'&&!paused)V3.set(!V3.on)});
 let pref='1';try{pref=localStorage.getItem('vr_3d')||'1'}catch(e){}V3.set(pref!='0');return true};
if(document.readyState=='loading')addEventListener('DOMContentLoaded',V3.init);else V3.init();
})();
