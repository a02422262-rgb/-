ГОЛОС СПО / ИНФОРМАТОРА
=======================
По умолчанию фразы произносит голос браузера (русский женский для «Риты» — советские самолёты; английский для «Betty» — западные; французский для Mirage/Rafale).
Настоящие записи подключаются так: положите файлы (.ogg/.mp3/.wav) в эту папку и впишите в sounds/manifest.json:
  { "rita":  { "irrad":"rita/irrad.ogg", "lock":"rita/lock.ogg", "launch":"rita/launch.ogg", "missile":"rita/missile.ogg",
               "fuel":"rita/fuel.ogg", "fuel_crit":"rita/fuel_crit.ogg", "gear":"rita/gear.ogg", "alt":"rita/alt.ogg" },
    "betty": { "irrad":"betty/radar.ogg", "lock":"betty/lock.ogg", "launch":"betty/launch.ogg", "missile":"betty/missile.ogg",
               "fuel":"betty/fuel.ogg", "fuel_crit":"betty/bingo.ogg", "gear":"betty/gear.ogg", "alt":"betty/pullup.ogg" },
    "fr":    { "irrad":"fr/radar.ogg", "lock":"fr/lock.ogg", "launch":"fr/launch.ogg", "missile":"fr/missile.ogg" } }
Ключи: irrad — облучение РЛС, lock — захват, launch — пуск ракеты по вам, missile — ракета в полёте, fuel — мало топлива,
fuel_crit — критический остаток, gear — шасси не выпущены, alt — опасная высота. Нет файла — звучит голос браузера.
Записи берите только те, на которые у вас есть права.
